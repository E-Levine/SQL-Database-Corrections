
INSERT INTO [dbo].[TripInfo]
           ([TripID]
           ,[TripType]
           ,[TripDate]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy])
     VALUES
      ('SSSHBG_20240920_1'
      ,'Shell Budget'
      ,'2024-09-20'
      ,'Proofed'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze')
 GO


INSERT INTO [dbo].[SampleEvent]
           ([SampleEventID]
           ,[TripID]
           ,[FixedLocationID]
           ,[LatitudeDec]
           ,[LongitudeDec]
           ,[NumDrills]
           ,[HarvestStatus]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy])
     VALUES
      ('SSSHBG_20240920_1_0619_1'
      ,'SSSHBG_20240920_1'
      ,'0619'
      ,'29.26713'
      ,'-83.08253'
      ,NULL
      ,'Prohibited'
      ,'Proofed'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze')
 GO


INSERT INTO [dbo].[SampleEvent]
           ([SampleEventID]
           ,[TripID]
           ,[FixedLocationID]
           ,[LatitudeDec]
           ,[LongitudeDec]
           ,[NumDrills]
           ,[HarvestStatus]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy])
     VALUES
      ('SSSHBG_20240920_1_0621_1'
      ,'SSSHBG_20240920_1'
      ,'0621'
      ,'29.26422'
      ,'-83.08061'
      ,NULL
      ,'Prohibited'
      ,'Proofed'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze')
 GO


INSERT INTO [dbo].[SampleEvent]
           ([SampleEventID]
           ,[TripID]
           ,[FixedLocationID]
           ,[LatitudeDec]
           ,[LongitudeDec]
           ,[NumDrills]
           ,[HarvestStatus]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy])
     VALUES
      ('SSSHBG_20240920_1_0622_1'
      ,'SSSHBG_20240920_1'
      ,'0622'
      ,'29.26569'
      ,'-83.08138'
      ,NULL
      ,'Prohibited'
      ,'Proofed'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze')
 GO


INSERT INTO [dbo].[SampleEventWQ]
           ([SampleEventWQID]
           ,[SampleEventID]
           ,[Temperature]
           ,[Salinity]
           ,[DissolvedOxygen]
           ,[pH]
           ,[Depth]
           ,[TurbidityYSI]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments]
           ,[CollectionTime])
     VALUES
      ('SSSHBG_20240920_1_0619_1_01'
      ,'SSSHBG_20240920_1_0619_1'
      ,'28.6'
      ,'9.77'
      ,'4.28'
      ,'7.08'
      ,'0.5'
      ,'15.4'
      ,'Proofed'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL
      ,'1049')
 GO


INSERT INTO [dbo].[SampleEventWQ]
           ([SampleEventWQID]
           ,[SampleEventID]
           ,[Temperature]
           ,[Salinity]
           ,[DissolvedOxygen]
           ,[pH]
           ,[Depth]
           ,[TurbidityYSI]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments]
           ,[CollectionTime])
     VALUES
      ('SSSHBG_20240920_1_0621_1_01'
      ,'SSSHBG_20240920_1_0621_1'
      ,'30.1'
      ,'9.75'
      ,'5.52'
      ,'7.29'
      ,'0.6'
      ,'3.29'
      ,'Proofed'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze'
      ,'BOTTOM_TYP = OY'
      ,'1315')
 GO


INSERT INTO [dbo].[SampleEventWQ]
           ([SampleEventWQID]
           ,[SampleEventID]
           ,[Temperature]
           ,[Salinity]
           ,[DissolvedOxygen]
           ,[pH]
           ,[Depth]
           ,[TurbidityYSI]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments]
           ,[CollectionTime])
     VALUES
      ('SSSHBG_20240920_1_0622_1_01'
      ,'SSSHBG_20240920_1_0622_1'
      ,'31.3'
      ,'10.63'
      ,'5.35'
      ,'7.15'
      ,'0.4'
      ,'18.4'
      ,'Proofed'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL
      ,'1211')
 GO
