
INSERT INTO [dbo].[TripInfo]
           ([TripID]
           ,[TripType]
           ,[TripDate]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy])
     VALUES
      ('SSSHBG_20240828_1'
      ,'Shell Budget'
      ,'2024-08-28'
      ,'Proofed'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze')
 GO


INSERT INTO [dbo].[SampleEvent]
           ([SampleEventID]
           ,[TripID]
           ,[FixedLocationID]
           ,[LatitudeDec]
           ,[LongitudeDec]
           ,[NumDrills]
           ,[HarvestStatus]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy])
     VALUES
      ('SSSHBG_20240828_1_0603_1'
      ,'SSSHBG_20240828_1'
      ,'0603'
      ,'29.23308'
      ,'-83.14063'
      ,NULL
      ,'Approved'
      ,'Proofed'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze')
 GO


INSERT INTO [dbo].[SampleEvent]
           ([SampleEventID]
           ,[TripID]
           ,[FixedLocationID]
           ,[LatitudeDec]
           ,[LongitudeDec]
           ,[NumDrills]
           ,[HarvestStatus]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy])
     VALUES
      ('SSSHBG_20240828_1_0604_1'
      ,'SSSHBG_20240828_1'
      ,'0604'
      ,'29.23404'
      ,'-83.1429'
      ,NULL
      ,'Approved'
      ,'Proofed'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze')
 GO


INSERT INTO [dbo].[SampleEvent]
           ([SampleEventID]
           ,[TripID]
           ,[FixedLocationID]
           ,[LatitudeDec]
           ,[LongitudeDec]
           ,[NumDrills]
           ,[HarvestStatus]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy])
     VALUES
      ('SSSHBG_20240828_1_0605_1'
      ,'SSSHBG_20240828_1'
      ,'0605'
      ,'29.2367'
      ,'-83.14585'
      ,NULL
      ,'Approved'
      ,'Proofed'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze')
 GO


INSERT INTO [dbo].[SampleEventWQ]
           ([SampleEventWQID]
           ,[SampleEventID]
           ,[Temperature]
           ,[Salinity]
           ,[DissolvedOxygen]
           ,[pH]
           ,[Depth]
           ,[TurbidityYSI]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments]
           ,[CollectionTime])
     VALUES
      ('SSSHBG_20240828_1_0603_1_01'
      ,'SSSHBG_20240828_1_0603_1'
      ,'30.1'
      ,'28.18'
      ,'5.97'
      ,'7.82'
      ,'2.25'
      ,'1.4'
      ,'Proofed'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze'
      ,'DPTH_STRTA = S BOTTOM_TYP = SA'
      ,'0930')
 GO


INSERT INTO [dbo].[SampleEventWQ]
           ([SampleEventWQID]
           ,[SampleEventID]
           ,[Temperature]
           ,[Salinity]
           ,[DissolvedOxygen]
           ,[pH]
           ,[Depth]
           ,[TurbidityYSI]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments]
           ,[CollectionTime])
     VALUES
      ('SSSHBG_20240828_1_0604_1_01'
      ,'SSSHBG_20240828_1_0604_1'
      ,'30.2'
      ,'27.55'
      ,'6.22'
      ,'7.8'
      ,'2.5'
      ,'1.19'
      ,'Proofed'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze'
      ,'DPTH_STRTA = S BOTTOM_TYP = HA'
      ,'1024')
 GO


INSERT INTO [dbo].[SampleEventWQ]
           ([SampleEventWQID]
           ,[SampleEventID]
           ,[Temperature]
           ,[Salinity]
           ,[DissolvedOxygen]
           ,[pH]
           ,[Depth]
           ,[TurbidityYSI]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments]
           ,[CollectionTime])
     VALUES
      ('SSSHBG_20240828_1_0605_1_01'
      ,'SSSHBG_20240828_1_0605_1'
      ,'30.3'
      ,'28.47'
      ,'6.02'
      ,'7.79'
      ,'2'
      ,'0.61'
      ,'Proofed'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze'
      ,'DPTH_STRTA = S BOTTOM_TYP = SA'
      ,'1109')
 GO
