
INSERT INTO [dbo].[TripInfo]
           ([TripID]
           ,[TripType]
           ,[TripDate]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy])
     VALUES
      ('SSSHBG_20260116_1'
      ,'Shell Budget'
      ,'2026-01-16'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze')
 GO


INSERT INTO [dbo].[SampleEvent]
           ([SampleEventID]
           ,[TripID]
           ,[FixedLocationID]
           ,[LatitudeDec]
           ,[LongitudeDec]
           ,[NumDrills]
           ,[HarvestStatus]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy])
     VALUES
      ('SSSHBG_20260116_1_0616_1'
      ,'SSSHBG_20260116_1'
      ,'0616'
      ,'29.23411'
      ,'-83.07151'
      ,NULL
      ,'Conditionally Approved'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze')
 GO


INSERT INTO [dbo].[SampleEvent]
           ([SampleEventID]
           ,[TripID]
           ,[FixedLocationID]
           ,[LatitudeDec]
           ,[LongitudeDec]
           ,[NumDrills]
           ,[HarvestStatus]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy])
     VALUES
      ('SSSHBG_20260116_1_0617_1'
      ,'SSSHBG_20260116_1'
      ,'0617'
      ,'29.23081'
      ,'-83.07713'
      ,NULL
      ,'Conditionally Approved'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze')
 GO


INSERT INTO [dbo].[SampleEvent]
           ([SampleEventID]
           ,[TripID]
           ,[FixedLocationID]
           ,[LatitudeDec]
           ,[LongitudeDec]
           ,[NumDrills]
           ,[HarvestStatus]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy])
     VALUES
      ('SSSHBG_20260116_1_0618_1'
      ,'SSSHBG_20260116_1'
      ,'0618'
      ,'29.23574'
      ,'-83.07247'
      ,NULL
      ,'Conditionally Approved'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze')
 GO


INSERT INTO [dbo].[SampleEventWQ]
           ([SampleEventWQID]
           ,[SampleEventID]
           ,[Temperature]
           ,[Salinity]
           ,[DissolvedOxygen]
           ,[pH]
           ,[Depth]
           ,[TurbidityYSI]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments]
           ,[CollectionTime])
     VALUES
      ('SSSHBG_20260116_1_0616_1_01'
      ,'SSSHBG_20260116_1_0616_1'
      ,'11.9'
      ,'20.67'
      ,'9.62'
      ,'7.98'
      ,'0.4'
      ,'17.95'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'DPTH_STRTA = I BOTTOM_TYP = OY'
      ,'1300')
 GO


INSERT INTO [dbo].[SampleEventWQ]
           ([SampleEventWQID]
           ,[SampleEventID]
           ,[Temperature]
           ,[Salinity]
           ,[DissolvedOxygen]
           ,[pH]
           ,[Depth]
           ,[TurbidityYSI]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments]
           ,[CollectionTime])
     VALUES
      ('SSSHBG_20260116_1_0617_1_01'
      ,'SSSHBG_20260116_1_0617_1'
      ,'9.9'
      ,'21.25'
      ,'9.28'
      ,'7.93'
      ,'0.3'
      ,'53.63'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'DPTH_STRTA = I BOTTOM_TYP = OY'
      ,'1056')
 GO


INSERT INTO [dbo].[SampleEventWQ]
           ([SampleEventWQID]
           ,[SampleEventID]
           ,[Temperature]
           ,[Salinity]
           ,[DissolvedOxygen]
           ,[pH]
           ,[Depth]
           ,[TurbidityYSI]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments]
           ,[CollectionTime])
     VALUES
      ('SSSHBG_20260116_1_0618_1_01'
      ,'SSSHBG_20260116_1_0618_1'
      ,'10.5'
      ,'20.42'
      ,'9.31'
      ,'7.96'
      ,'0.5'
      ,'28.3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'DPTH_STRTA = I BOTTOM_TYP = OY'
      ,'1203')
 GO
