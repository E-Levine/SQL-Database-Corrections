
INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01'
      ,'SSSHBG_20250128_1_0617_1'
      ,'1'
      ,'1.5'
      ,'4.2'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'302'
      ,'33'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02'
      ,'SSSHBG_20250128_1_0617_1'
      ,'2'
      ,'1.75'
      ,'3.8'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'215'
      ,'50'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03'
      ,'SSSHBG_20250128_1_0617_1'
      ,'3'
      ,'1.75'
      ,'5.5'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'405'
      ,'36'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04'
      ,'SSSHBG_20250128_1_0617_1'
      ,'4'
      ,'3.75'
      ,'7.1'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'401'
      ,'65'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05'
      ,'SSSHBG_20250128_1_0617_1'
      ,'5'
      ,'5.5'
      ,'10.1'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'678'
      ,'116'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06'
      ,'SSSHBG_20250128_1_0617_1'
      ,'6'
      ,'3.75'
      ,'6.8'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'323'
      ,'66'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07'
      ,'SSSHBG_20250128_1_0617_1'
      ,'7'
      ,'2'
      ,'3.5'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'234'
      ,'36'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08'
      ,'SSSHBG_20250128_1_0617_1'
      ,'8'
      ,'1.5'
      ,'3.1'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'210'
      ,'18'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09'
      ,'SSSHBG_20250128_1_0617_1'
      ,'9'
      ,'1.5'
      ,'2.6'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'122'
      ,'45'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10'
      ,'SSSHBG_20250128_1_0617_1'
      ,'10'
      ,'2.25'
      ,'4'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'257'
      ,'25'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11'
      ,'SSSHBG_20250128_1_0617_1'
      ,'11'
      ,'1'
      ,'1.73'
      ,'0.5'
      ,'0.78'
      ,'0'
      ,'0'
      ,'0'
      ,'196'
      ,'55'
      ,'0.5'
      ,'0.83'
      ,'0'
      ,'0'
      ,'0'
      ,'0.17'
      ,'0'
      ,'0'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12'
      ,'SSSHBG_20250128_1_0617_1'
      ,'12'
      ,'3.75'
      ,'6.38'
      ,'1.5'
      ,'2.4'
      ,'0'
      ,'0'
      ,'0'
      ,'591'
      ,'125'
      ,'2'
      ,'3.39'
      ,'0'
      ,'0'
      ,'0.25'
      ,'0.7'
      ,'0'
      ,'0'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13'
      ,'SSSHBG_20250128_1_0617_1'
      ,'13'
      ,'1.25'
      ,'2.12'
      ,'1'
      ,'1.67'
      ,'0'
      ,'0'
      ,'0'
      ,'201'
      ,'7'
      ,'0.15'
      ,'0.31'
      ,'0'
      ,'0'
      ,'0.05'
      ,'0.15'
      ,'0'
      ,'0'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14'
      ,'SSSHBG_20250128_1_0617_1'
      ,'14'
      ,'3.5'
      ,'4.76'
      ,'1.5'
      ,'3.21'
      ,'0'
      ,'0'
      ,'0'
      ,'232'
      ,'24'
      ,'0.6'
      ,'1.06'
      ,'0'
      ,'0'
      ,'0.3'
      ,'0.55'
      ,'0'
      ,'0.04'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 1')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15'
      ,'SSSHBG_20250128_1_0617_1'
      ,'15'
      ,'2.6'
      ,'5.48'
      ,'2'
      ,'3.88'
      ,'0'
      ,'0'
      ,'0'
      ,'336'
      ,'34'
      ,'0.6'
      ,'1.2'
      ,'0'
      ,'0'
      ,'0.3'
      ,'0.57'
      ,'0'
      ,'0.05'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_001'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'71'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_002'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'23'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_003'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'31'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_004'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'44'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_005'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'49'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_006'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'34'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_007'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'39'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_008'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'34'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_009'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'43'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_010'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'25'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_011'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'18'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_012'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'29'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_013'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'13'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_014'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'13'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_015'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_016'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'34'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_017'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'30'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_018'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'30'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_019'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'14'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_020'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'38'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_021'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'39'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_022'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'31'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_023'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'14'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_024'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'17'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_025'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'39'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_026'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_027'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'34'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_028'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'24'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_029'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'27'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_030'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'13'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_031'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'73'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_032'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'17'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_033'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'39'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_034'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'22'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_035'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'48'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_036'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'18'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_037'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'18'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_038'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'29'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_039'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'19'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_040'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'22'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_041'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'27'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_042'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'35'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_043'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'22'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_044'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_045'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'21'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_046'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_047'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'22'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_048'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'43'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_049'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'27'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_01_050'
      ,'SSSHBG_20250128_1_0617_1_01'
      ,'Live'
      ,'22'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_001'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'45'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_002'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'26'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_003'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'55'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_004'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'25'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_005'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'40'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_006'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'32'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_007'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'21'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_008'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'40'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_009'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'16'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_010'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'19'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_011'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'65'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_012'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'43'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_013'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'30'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_014'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'29'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_015'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'24'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_016'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'19'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_017'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'24'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_018'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_019'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'9'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_020'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'44'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_021'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'39'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_022'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'37'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_023'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'34'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_024'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'53'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_025'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'38'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_026'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'25'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_027'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'43'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_028'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'24'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_029'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'45'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_030'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_031'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'9'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_032'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'41'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_033'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'27'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_034'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'59'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_035'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_036'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'23'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_037'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'22'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_038'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'37'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_039'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'21'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_040'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'43'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_041'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'34'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_042'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'46'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_043'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'29'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_044'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'35'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_045'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'45'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_046'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'42'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_047'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'39'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_048'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'35'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_049'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'48'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_02_050'
      ,'SSSHBG_20250128_1_0617_1_02'
      ,'Live'
      ,'60'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_001'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'68'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_002'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'25'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_003'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'50'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_004'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'30'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_005'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'46'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_006'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_007'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'54'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_008'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'48'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_009'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'40'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_010'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'30'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_011'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'26'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_012'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_013'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'35'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_014'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'31'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_015'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'37'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_016'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'22'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_017'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'17'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_018'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'24'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_019'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'14'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_020'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'34'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_021'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'29'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_022'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_023'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'28'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_024'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'29'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_025'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'40'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_026'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_027'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'28'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_028'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'17'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_029'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'56'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_030'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'31'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_031'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'50'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_032'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'26'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_033'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'22'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_034'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'30'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_035'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'34'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_036'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'32'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_037'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'18'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_038'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'18'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_039'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'37'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_040'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'32'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_041'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'22'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_042'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'34'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_043'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'22'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_044'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'21'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_045'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'40'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_046'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'39'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_047'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'38'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_048'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'34'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_049'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'32'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_03_050'
      ,'SSSHBG_20250128_1_0617_1_03'
      ,'Live'
      ,'29'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_001'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'51'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_002'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'26'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_003'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_004'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'29'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_005'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'27'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_006'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'35'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_007'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_008'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'31'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_009'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'24'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_010'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_011'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'22'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_012'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'47'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_013'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'31'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_014'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'18'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_015'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'43'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_016'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'37'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_017'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'33'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_018'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'14'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_019'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'40'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_020'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'47'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_021'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'19'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_022'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'30'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_023'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'24'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_024'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'13'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_025'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'50'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_026'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'42'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_027'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'22'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_028'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'42'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_029'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'32'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_030'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'25'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_031'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'35'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_032'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'30'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_033'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'27'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_034'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'26'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_035'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'16'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_036'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'23'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_037'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'28'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_038'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'65'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_039'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'17'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_040'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_041'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'34'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_042'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'19'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_043'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_044'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'25'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_045'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'42'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_046'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_047'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'22'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_048'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_049'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'22'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_04_050'
      ,'SSSHBG_20250128_1_0617_1_04'
      ,'Live'
      ,'42'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_001'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'40'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_002'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_003'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'33'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_004'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'52'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_005'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'30'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_006'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'35'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_007'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'23'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_008'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'27'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_009'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'42'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_010'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'45'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_011'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'27'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_012'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'34'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_013'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'27'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_014'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'28'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_015'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'25'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_016'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'21'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_017'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'25'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_018'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'17'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_019'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_020'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'35'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_021'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'38'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_022'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'18'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_023'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'30'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_024'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_025'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'26'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_026'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'37'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_027'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'74'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_028'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'33'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_029'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'54'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_030'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'22'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_031'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'26'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_032'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'33'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_033'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'38'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_034'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'24'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_035'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'26'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_036'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'45'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_037'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'37'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_038'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'42'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_039'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'41'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_040'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'30'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_041'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_042'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_043'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'56'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_044'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'38'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_045'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'38'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_046'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'25'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_047'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_048'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'35'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_049'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'34'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_05_050'
      ,'SSSHBG_20250128_1_0617_1_05'
      ,'Live'
      ,'41'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_001'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'39'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_002'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'52'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_003'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'67'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_004'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'17'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_005'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'22'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_006'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'24'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_007'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_008'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'35'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_009'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'35'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_010'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_011'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'25'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_012'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'30'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_013'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'14'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_014'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'32'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_015'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'22'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_016'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_017'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'26'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_018'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'24'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_019'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'30'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_020'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'54'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_021'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'32'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_022'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'33'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_023'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_024'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'26'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_025'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'28'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_026'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'28'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_027'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'27'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_028'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'24'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_029'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'35'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_030'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'18'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_031'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'25'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_032'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'31'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_033'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'21'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_034'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_035'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'17'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_036'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'9'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_037'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_038'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'28'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_039'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'35'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_040'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'32'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_041'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'42'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_042'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'13'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_043'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_044'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'27'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_045'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'70'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_046'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'37'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_047'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'27'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_048'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'32'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_049'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'45'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_06_050'
      ,'SSSHBG_20250128_1_0617_1_06'
      ,'Live'
      ,'30'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_001'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'42'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_002'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'44'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_003'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'31'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_004'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'30'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_005'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'22'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_006'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'25'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_007'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'26'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_008'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'21'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_009'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'29'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_010'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'35'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_011'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'25'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_012'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'34'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_013'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'25'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_014'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'34'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_015'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'32'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_016'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'42'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_017'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'31'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_018'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'28'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_019'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_020'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'58'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_021'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'37'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_022'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'34'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_023'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'33'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_024'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'31'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_025'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'27'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_026'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'39'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_027'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'35'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_028'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'30'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_029'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'34'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_030'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'29'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_031'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'30'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_032'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'56'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_033'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'40'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_034'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'42'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_035'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'33'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_036'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'34'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_037'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'35'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_038'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_039'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'30'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_040'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'23'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_041'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'33'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_042'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_043'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'25'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_044'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'26'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_045'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'29'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_046'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'30'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_047'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'28'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_048'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'50'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_049'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'42'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_07_050'
      ,'SSSHBG_20250128_1_0617_1_07'
      ,'Live'
      ,'29'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_001'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'80'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_002'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_003'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'26'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_004'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'35'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_005'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'49'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_006'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'30'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_007'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'30'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_008'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'35'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_009'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_010'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'29'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_011'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'34'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_012'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'40'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_013'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'37'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_014'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'29'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_015'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'27'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_016'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'39'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_017'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'27'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_018'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'40'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_019'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'16'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_020'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'25'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_021'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'17'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_022'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'40'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_023'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'17'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_024'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'17'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_025'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'34'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_026'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'30'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_027'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'26'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_028'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'37'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_029'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'45'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_030'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'37'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_031'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'16'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_032'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'60'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_033'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'26'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_034'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'45'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_035'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'32'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_036'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'21'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_037'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'29'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_038'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'29'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_039'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'25'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_040'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'34'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_041'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'22'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_042'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'23'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_043'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'25'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_044'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'33'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_045'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'30'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_046'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'29'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_047'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'40'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_048'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'27'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_049'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'18'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_08_050'
      ,'SSSHBG_20250128_1_0617_1_08'
      ,'Live'
      ,'26'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_001'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'49'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_002'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'31'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_003'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'28'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_004'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_005'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'27'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_006'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'38'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_007'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'45'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_008'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_009'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'36'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_010'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'17'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_011'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_012'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'34'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_013'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'44'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_014'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'28'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_015'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_016'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'27'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_017'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'28'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_018'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'28'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_019'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'26'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_020'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'30'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_021'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'31'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_022'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'37'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_023'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'41'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_024'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'13'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_025'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'35'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_026'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'52'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_027'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'31'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_028'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'41'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_029'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'42'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_030'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'35'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_031'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'27'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_032'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'30'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_033'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'40'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_034'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'27'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_035'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'49'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_036'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_037'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'17'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_038'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'24'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_039'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'25'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_040'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'28'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_041'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'28'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_042'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'25'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_043'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'22'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_044'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'29'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_045'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'42'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_046'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'45'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_047'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'45'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_048'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'29'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_049'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'25'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_09_050'
      ,'SSSHBG_20250128_1_0617_1_09'
      ,'Live'
      ,'30'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_001'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'36'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_002'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'32'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_003'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'33'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_004'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'32'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_005'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'25'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_006'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'29'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_007'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'17'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_008'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'49'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_009'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'65'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_010'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'36'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_011'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'19'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_012'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'60'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_013'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'33'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_014'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'29'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_015'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'26'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_016'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'35'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_017'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'24'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_018'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_019'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'58'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_020'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'63'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_021'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'45'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_022'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'22'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_023'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'42'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_024'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'58'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_025'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'49'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_026'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'40'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_027'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'27'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_028'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'22'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_029'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'25'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_030'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'28'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_031'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'56'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_032'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'58'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_033'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'39'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_034'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'43'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_035'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'23'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_036'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'25'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_037'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'34'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_038'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'33'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_039'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'36'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_040'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'26'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_041'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'31'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_042'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'30'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_043'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'40'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_044'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'31'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_045'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'16'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_046'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'39'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_047'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'26'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_048'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'24'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_049'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'26'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_10_050'
      ,'SSSHBG_20250128_1_0617_1_10'
      ,'Live'
      ,'25'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_001'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'36'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_002'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'28'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_003'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'42'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_004'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_005'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'38'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_006'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'38'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_007'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'47'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_008'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'48'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_009'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'21'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_010'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'26'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_011'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'21'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_012'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'31'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_013'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'27'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_014'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'35'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_015'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'40'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_016'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'28'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_017'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_018'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_019'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'19'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_020'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_021'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_022'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'36'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_023'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'36'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_024'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'16'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_025'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_026'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'28'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_027'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'42'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_028'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'19'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_029'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_030'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_031'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_032'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'25'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_033'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'30'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_034'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_035'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'23'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_036'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'40'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_037'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'65'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_038'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'35'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_039'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'38'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_040'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'23'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_041'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'30'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_042'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_043'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'26'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_044'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'25'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_045'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_046'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'45'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_047'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'35'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_048'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'22'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_049'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'23'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_050'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Live'
      ,'33'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_051'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'21'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_052'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_053'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_054'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'25'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_055'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'34'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_056'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'14'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_057'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'13'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_058'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_059'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_060'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'13'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_061'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'14'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_062'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'48'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_063'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'46'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_064'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'24'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_065'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_066'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_067'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'60'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_068'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'35'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_069'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'23'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_070'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'45'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_071'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'66'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_072'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'37'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_073'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_074'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'47'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_075'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'50'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_076'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'27'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_077'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_078'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'37'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_079'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'40'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_080'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'23'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_081'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'21'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_082'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'22'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_083'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_084'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'34'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_085'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'23'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_086'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'35'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_087'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_088'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'34'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_089'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_090'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_091'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'60'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_092'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_093'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'47'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_094'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'57'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_095'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'42'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_096'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_097'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'28'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_098'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'30'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_099'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_11_100'
      ,'SSSHBG_20250128_1_0617_1_11'
      ,'Dead'
      ,'22'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_001'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'31'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_002'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'34'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_003'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'39'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_004'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'33'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_005'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'38'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_006'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'50'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_007'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'17'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_008'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'22'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_009'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_010'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_011'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'30'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_012'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'17'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_013'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'25'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_014'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_015'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'25'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_016'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'27'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_017'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'43'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_018'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'23'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_019'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'52'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_020'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'30'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_021'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'17'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_022'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'37'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_023'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'23'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_024'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'25'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_025'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'32'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_026'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'24'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_027'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'18'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_028'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_029'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'27'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_030'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'32'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_031'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_032'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'35'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_033'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'44'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_034'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'42'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_035'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'55'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_036'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'24'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_037'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'37'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_038'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'23'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_039'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'17'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_040'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'42'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_041'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'27'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_042'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'32'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_043'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'47'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_044'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'13'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_045'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'28'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_046'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_047'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'25'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_048'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'21'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_049'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'23'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_050'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Live'
      ,'35'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_051'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_052'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'14'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_053'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'46'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_054'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'70'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_055'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'13'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_056'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'31'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_057'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'18'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_058'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_059'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'18'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_060'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'21'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_061'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'24'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_062'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_063'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'60'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_064'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'75'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_065'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'17'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_066'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'18'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_067'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'62'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_068'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'22'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_069'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_070'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_071'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'35'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_072'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_073'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'17'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_074'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'17'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_075'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'21'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_076'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_077'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'34'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_078'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'24'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_079'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'14'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_080'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'30'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_081'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_082'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'40'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_083'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'25'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_084'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'17'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_085'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'48'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_086'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'30'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_087'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'54'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_088'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'16'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_089'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'76'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_090'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'29'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_091'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'30'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_092'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'32'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_093'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'21'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_094'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'32'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_095'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'29'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_096'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'32'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_097'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_098'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'43'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_099'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'42'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_12_100'
      ,'SSSHBG_20250128_1_0617_1_12'
      ,'Dead'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_001'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'51'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_002'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'52'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_003'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'30'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_004'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'32'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_005'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'40'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_006'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'30'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_007'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'25'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_008'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'30'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_009'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'30'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_010'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'31'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_011'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'45'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_012'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'32'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_013'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'35'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_014'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'45'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_015'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'25'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_016'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'60'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_017'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_018'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'16'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_019'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_020'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_021'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_022'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'30'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_023'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_024'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_025'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_026'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_027'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_028'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_029'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_030'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'18'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_031'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_032'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'30'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_033'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'35'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_034'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'50'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_035'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'57'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_036'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_037'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'30'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_038'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'52'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_039'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'35'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_040'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'65'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_041'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_042'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_043'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_044'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_045'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_046'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_047'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'30'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_048'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'55'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_049'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'40'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_050'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Live'
      ,'45'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_051'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Dead'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_052'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Dead'
      ,'22'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_053'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Dead'
      ,'23'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_054'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Dead'
      ,'32'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_055'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Dead'
      ,'32'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_056'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Dead'
      ,'21'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_13_057'
      ,'SSSHBG_20250128_1_0617_1_13'
      ,'Dead'
      ,'33'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_001'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'44'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_002'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'52'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_003'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'33'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_004'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'55'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_005'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'27'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_006'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'35'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_007'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'37'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_008'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'45'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_009'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'47'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_010'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'29'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_011'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'38'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_012'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'34'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_013'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'32'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_014'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'44'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_015'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'57'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_016'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'27'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_017'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'38'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_018'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'63'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_019'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'39'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_020'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'57'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_021'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'24'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_022'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'53'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_023'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'41'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_024'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'35'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_025'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'43'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_026'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'52'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_027'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'45'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_028'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'26'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_029'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'37'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_030'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'31'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_031'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'29'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_032'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'35'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_033'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'37'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_034'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'40'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_035'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'45'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_036'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'29'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_037'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'32'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_038'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'25'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_039'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'51'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_040'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'18'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_041'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'40'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_042'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'45'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_043'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'26'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_044'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'53'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_045'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'42'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_046'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'38'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_047'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'46'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_048'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'41'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_049'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'33'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_050'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Live'
      ,'31'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_051'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Dead'
      ,'23'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_052'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Dead'
      ,'24'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_053'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Dead'
      ,'45'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_054'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Dead'
      ,'54'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_055'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Dead'
      ,'33'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_056'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Dead'
      ,'17'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_057'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Dead'
      ,'29'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_058'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Dead'
      ,'19'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_059'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Dead'
      ,'31'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_060'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Dead'
      ,'37'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_061'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Dead'
      ,'21'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_062'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Dead'
      ,'19'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_063'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Dead'
      ,'43'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_064'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Dead'
      ,'39'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_065'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Dead'
      ,'27'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_066'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Dead'
      ,'43'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_067'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Dead'
      ,'33'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_068'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Dead'
      ,'37'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_069'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Dead'
      ,'48'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_070'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Dead'
      ,'40'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_071'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Dead'
      ,'53'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_072'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Dead'
      ,'71'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_073'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Dead'
      ,'51'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_14_074'
      ,'SSSHBG_20250128_1_0617_1_14'
      ,'Dead'
      ,'29'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_001'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'46'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_002'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'27'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_003'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'41'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_004'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'19'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_005'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'24'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_006'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'43'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_007'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'31'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_008'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'35'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_009'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'44'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_010'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'29'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_011'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'41'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_012'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'21'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_013'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'23'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_014'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'32'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_015'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'24'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_016'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'33'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_017'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'29'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_018'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'53'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_019'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'51'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_020'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'42'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_021'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'37'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_022'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'39'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_023'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'48'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_024'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'36'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_025'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'38'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_026'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'51'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_027'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'36'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_028'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'21'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_029'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'39'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_030'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'37'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_031'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'63'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_032'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'49'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_033'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'44'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_034'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'40'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_035'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'39'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_036'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'29'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_037'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'38'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_038'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'41'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_039'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'27'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_040'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'47'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_041'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'49'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_042'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'57'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_043'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'24'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_044'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'33'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_045'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'44'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_046'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'56'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_047'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'34'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_048'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'29'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_049'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'37'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_050'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Live'
      ,'40'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_051'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Dead'
      ,'31'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_052'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Dead'
      ,'55'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_053'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Dead'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_054'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Dead'
      ,'31'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_055'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Dead'
      ,'25'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_056'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Dead'
      ,'38'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_057'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Dead'
      ,'62'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_058'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Dead'
      ,'37'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_059'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Dead'
      ,'35'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_060'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Dead'
      ,'50'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_061'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Dead'
      ,'29'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_062'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Dead'
      ,'26'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_063'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Dead'
      ,'31'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_064'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Dead'
      ,'34'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_065'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Dead'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_066'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Dead'
      ,'55'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_067'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Dead'
      ,'41'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_068'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Dead'
      ,'71'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_069'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Dead'
      ,'42'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_070'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Dead'
      ,'39'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_071'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Dead'
      ,'45'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_072'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Dead'
      ,'47'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_073'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Dead'
      ,'49'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_074'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Dead'
      ,'35'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_075'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Dead'
      ,'37'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_076'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Dead'
      ,'43'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_077'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Dead'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_078'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Dead'
      ,'71'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_079'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Dead'
      ,'14'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_080'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Dead'
      ,'46'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_081'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Dead'
      ,'72'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_082'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Dead'
      ,'37'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_083'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Dead'
      ,'44'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20250128_1_0617_1_15_084'
      ,'SSSHBG_20250128_1_0617_1_15'
      ,'Dead'
      ,'39'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO
