
INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_01'
      ,'SSSHBG_20251203_1_0603_1'
      ,'1'
      ,'0.3'
      ,'0.58'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'8'
      ,'7'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_02'
      ,'SSSHBG_20251203_1_0603_1'
      ,'2'
      ,'0.45'
      ,'0.81'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'1'
      ,'1'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_03'
      ,'SSSHBG_20251203_1_0603_1'
      ,'3'
      ,'0.01'
      ,'0.1'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'9'
      ,'0'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_04'
      ,'SSSHBG_20251203_1_0603_1'
      ,'4'
      ,'0.1'
      ,'0.21'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'4'
      ,'5'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_05'
      ,'SSSHBG_20251203_1_0603_1'
      ,'5'
      ,'0.01'
      ,'0.05'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_06'
      ,'SSSHBG_20251203_1_0603_1'
      ,'6'
      ,'0.05'
      ,'0.11'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'16'
      ,'0'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_07'
      ,'SSSHBG_20251203_1_0603_1'
      ,'7'
      ,'0.25'
      ,'0.47'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'5'
      ,'2'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Notes = 1 juv sto Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_08'
      ,'SSSHBG_20251203_1_0603_1'
      ,'8'
      ,'0.4'
      ,'0.8'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'6'
      ,'3'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Notes = 1sto Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_09'
      ,'SSSHBG_20251203_1_0603_1'
      ,'9'
      ,'0.2'
      ,'0.37'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'5'
      ,'4'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 2')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_10'
      ,'SSSHBG_20251203_1_0603_1'
      ,'10'
      ,'0.01'
      ,'0.07'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_11'
      ,'SSSHBG_20251203_1_0603_1'
      ,'11'
      ,'0.5'
      ,'0.87'
      ,'0.01'
      ,'0.01'
      ,'0'
      ,'0'
      ,'0.01'
      ,'1'
      ,'5'
      ,'0.25'
      ,'0.67'
      ,'0'
      ,'0'
      ,'0.13'
      ,'0.2'
      ,'0'
      ,'0'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_12'
      ,'SSSHBG_20251203_1_0603_1'
      ,'12'
      ,'0.25'
      ,'0.48'
      ,'0'
      ,'0'
      ,'0'
      ,'0'
      ,'0'
      ,'0'
      ,'4'
      ,'0.15'
      ,'0.34'
      ,'0'
      ,'0'
      ,'0.13'
      ,'0.15'
      ,'0'
      ,'0'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_13'
      ,'SSSHBG_20251203_1_0603_1'
      ,'13'
      ,'0.13'
      ,'0.26'
      ,'0'
      ,'0'
      ,'1'
      ,'0.02'
      ,'0.01'
      ,'3'
      ,'1'
      ,'0.05'
      ,'0.07'
      ,'0'
      ,'0'
      ,'0.05'
      ,'0.17'
      ,'0'
      ,'0'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 1')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_14'
      ,'SSSHBG_20251203_1_0603_1'
      ,'14'
      ,'0.35'
      ,'0.83'
      ,'0.01'
      ,'0.01'
      ,'0'
      ,'0'
      ,'0'
      ,'9'
      ,'12'
      ,'0.3'
      ,'0.73'
      ,'0'
      ,'0'
      ,'0.05'
      ,'0.1'
      ,'0'
      ,'0'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_15'
      ,'SSSHBG_20251203_1_0603_1'
      ,'15'
      ,'0.01'
      ,'0.09'
      ,'0.01'
      ,'0.01'
      ,'0'
      ,'0'
      ,'0'
      ,'3'
      ,'0'
      ,'0.01'
      ,'0.06'
      ,'0'
      ,'0'
      ,'0.01'
      ,'0.03'
      ,'0'
      ,'0'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_01'
      ,'SSSHBG_20251203_1_0604_1'
      ,'1'
      ,'0.45'
      ,'0.89'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'18'
      ,'2'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_02'
      ,'SSSHBG_20251203_1_0604_1'
      ,'2'
      ,'0.6'
      ,'1.25'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'15'
      ,'2'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Notes = 1 stone Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_03'
      ,'SSSHBG_20251203_1_0604_1'
      ,'3'
      ,'0.3'
      ,'0.57'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'2'
      ,'0'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Notes = 1 sto Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_04'
      ,'SSSHBG_20251203_1_0604_1'
      ,'4'
      ,'0.25'
      ,'0.56'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'3'
      ,'0'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_05'
      ,'SSSHBG_20251203_1_0604_1'
      ,'5'
      ,'0.15'
      ,'0.38'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'7'
      ,'1'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_06'
      ,'SSSHBG_20251203_1_0604_1'
      ,'6'
      ,'0.2'
      ,'0.46'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'1'
      ,'0'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_07'
      ,'SSSHBG_20251203_1_0604_1'
      ,'7'
      ,'0.15'
      ,'0.31'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'6'
      ,'1'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_08'
      ,'SSSHBG_20251203_1_0604_1'
      ,'8'
      ,'0.25'
      ,'0.51'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'17'
      ,'2'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_09'
      ,'SSSHBG_20251203_1_0604_1'
      ,'9'
      ,'0.4'
      ,'0.75'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'23'
      ,'2'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Notes = 1 sto Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_10'
      ,'SSSHBG_20251203_1_0604_1'
      ,'10'
      ,'0.35'
      ,'0.68'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'9'
      ,'3'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Notes = 1 sto Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_11'
      ,'SSSHBG_20251203_1_0604_1'
      ,'11'
      ,'0.1'
      ,'0.23'
      ,'0.01'
      ,'0.01'
      ,'0'
      ,'0'
      ,'0.01'
      ,'11'
      ,'1'
      ,'0.01'
      ,'0.04'
      ,'0.01'
      ,'0.01'
      ,'0.05'
      ,'0.11'
      ,'0.05'
      ,'0.07'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12'
      ,'SSSHBG_20251203_1_0604_1'
      ,'12'
      ,'0.5'
      ,'1.14'
      ,'0.01'
      ,'0.01'
      ,'0'
      ,'0'
      ,'0.01'
      ,'32'
      ,'18'
      ,'0.5'
      ,'0.81'
      ,'0'
      ,'0'
      ,'0.05'
      ,'0.29'
      ,'0'
      ,'0'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 2')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_13'
      ,'SSSHBG_20251203_1_0604_1'
      ,'13'
      ,'0.5'
      ,'1.06'
      ,'0.01'
      ,'0.01'
      ,'0'
      ,'0'
      ,'0'
      ,'33'
      ,'9'
      ,'0.25'
      ,'0.46'
      ,'0.15'
      ,'0.21'
      ,'0.15'
      ,'0.36'
      ,'0'
      ,'0'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 1')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_14'
      ,'SSSHBG_20251203_1_0604_1'
      ,'14'
      ,'0.13'
      ,'0.32'
      ,'0'
      ,'0'
      ,'0'
      ,'0'
      ,'0'
      ,'0'
      ,'0'
      ,'0.05'
      ,'0.16'
      ,'0'
      ,'0'
      ,'0.05'
      ,'0.15'
      ,'0'
      ,'0'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Notes = ZERO L AND D Conch = 1')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_15'
      ,'SSSHBG_20251203_1_0604_1'
      ,'15'
      ,'0.1'
      ,'0.27'
      ,'0'
      ,'0'
      ,'0'
      ,'0'
      ,'0.07'
      ,'15'
      ,'0'
      ,'0.05'
      ,'0.1'
      ,'0'
      ,'0'
      ,'0.05'
      ,'0.17'
      ,'0'
      ,'0'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_01'
      ,'SSSHBG_20251203_1_0605_1'
      ,'1'
      ,'0.15'
      ,'0.39'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'8'
      ,'0'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_02'
      ,'SSSHBG_20251203_1_0605_1'
      ,'2'
      ,'0.15'
      ,'0.31'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'8'
      ,'7'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_03'
      ,'SSSHBG_20251203_1_0605_1'
      ,'3'
      ,'0.2'
      ,'0.5'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'4'
      ,'0'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Notes = 1 stone Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_04'
      ,'SSSHBG_20251203_1_0605_1'
      ,'4'
      ,'0.15'
      ,'0.37'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'7'
      ,'0'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_05'
      ,'SSSHBG_20251203_1_0605_1'
      ,'5'
      ,'0.3'
      ,'0.77'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'19'
      ,'2'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Notes = 1juv stone Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_06'
      ,'SSSHBG_20251203_1_0605_1'
      ,'6'
      ,'0.2'
      ,'0.56'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'7'
      ,'0'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_07'
      ,'SSSHBG_20251203_1_0605_1'
      ,'7'
      ,'0.01'
      ,'0.08'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'3'
      ,'0'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_08'
      ,'SSSHBG_20251203_1_0605_1'
      ,'8'
      ,'0.15'
      ,'0.45'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'21'
      ,'6'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Notes = 2 stone Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_09'
      ,'SSSHBG_20251203_1_0605_1'
      ,'9'
      ,'0.3'
      ,'0.69'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'30'
      ,'11'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Notes = 2 sto Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_10'
      ,'SSSHBG_20251203_1_0605_1'
      ,'10'
      ,'0.5'
      ,'1.07'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'37'
      ,'0'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_11'
      ,'SSSHBG_20251203_1_0605_1'
      ,'11'
      ,'0.13'
      ,'0.27'
      ,'0'
      ,'0'
      ,'0'
      ,'0'
      ,'0.01'
      ,'0'
      ,'0'
      ,'0.01'
      ,'0.01'
      ,'0.13'
      ,'0.2'
      ,'0.01'
      ,'0.07'
      ,'0'
      ,'0'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Notes = ZEROES Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_12'
      ,'SSSHBG_20251203_1_0605_1'
      ,'12'
      ,'0.13'
      ,'0.31'
      ,'0.01'
      ,'0.01'
      ,'0'
      ,'0'
      ,'0.01'
      ,'6'
      ,'0'
      ,'0.13'
      ,'0.17'
      ,'0'
      ,'0'
      ,'0.01'
      ,'0.14'
      ,'0'
      ,'0'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_13'
      ,'SSSHBG_20251203_1_0605_1'
      ,'13'
      ,'0.13'
      ,'0.49'
      ,'0'
      ,'0'
      ,'0'
      ,'0'
      ,'0'
      ,'0'
      ,'0'
      ,'0.01'
      ,'0.06'
      ,'0'
      ,'0'
      ,'0.13'
      ,'0.45'
      ,'0'
      ,'0'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Notes = ZEROES Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14'
      ,'SSSHBG_20251203_1_0605_1'
      ,'14'
      ,'0.15'
      ,'0.3'
      ,'0.01'
      ,'0.01'
      ,'0'
      ,'0'
      ,'0'
      ,'54'
      ,'8'
      ,'0.01'
      ,'0.06'
      ,'0.1'
      ,'0.18'
      ,'0.01'
      ,'0.06'
      ,'0'
      ,'0'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15'
      ,'SSSHBG_20251203_1_0605_1'
      ,'15'
      ,'0.05'
      ,'0.11'
      ,'0.01'
      ,'0.01'
      ,'0'
      ,'0'
      ,'0'
      ,'60'
      ,'0'
      ,'0.01'
      ,'0.06'
      ,'0.01'
      ,'0.01'
      ,'0.01'
      ,'0.04'
      ,'0'
      ,'0'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_01'
      ,'SSSHBG_20251203_1_0606_1'
      ,'1'
      ,'0.1'
      ,'0.21'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'0'
      ,'12'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_02'
      ,'SSSHBG_20251203_1_0606_1'
      ,'2'
      ,'0.15'
      ,'0.21'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'6'
      ,'1'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Notes = 1stone Conch = 3')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_03'
      ,'SSSHBG_20251203_1_0606_1'
      ,'3'
      ,'0.01'
      ,'0.06'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'4'
      ,'1'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_04'
      ,'SSSHBG_20251203_1_0606_1'
      ,'4'
      ,'0.01'
      ,'0.13'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'1'
      ,'1'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_05'
      ,'SSSHBG_20251203_1_0606_1'
      ,'5'
      ,'0.3'
      ,'0.71'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_06'
      ,'SSSHBG_20251203_1_0606_1'
      ,'6'
      ,'0.01'
      ,'0.04'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'1'
      ,'0'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_07'
      ,'SSSHBG_20251203_1_0606_1'
      ,'7'
      ,'0.2'
      ,'0.38'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'6'
      ,'2'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_08'
      ,'SSSHBG_20251203_1_0606_1'
      ,'8'
      ,'0.25'
      ,'0.56'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'3'
      ,'1'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_09'
      ,'SSSHBG_20251203_1_0606_1'
      ,'9'
      ,'0.25'
      ,'0.56'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'1'
      ,'3'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_10'
      ,'SSSHBG_20251203_1_0606_1'
      ,'10'
      ,'0.05'
      ,'0.12'
      ,NULL
      ,NULL
      ,'0'
      ,NULL
      ,NULL
      ,'1'
      ,'0'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_11'
      ,'SSSHBG_20251203_1_0606_1'
      ,'11'
      ,'0.2'
      ,'0.35'
      ,'0.01'
      ,'0.01'
      ,'0'
      ,'0'
      ,'0'
      ,'1'
      ,'1'
      ,'0.15'
      ,'0.26'
      ,'0'
      ,'0'
      ,'0.01'
      ,'0.03'
      ,'0'
      ,'0'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_12'
      ,'SSSHBG_20251203_1_0606_1'
      ,'12'
      ,'0.7'
      ,'1.42'
      ,'0.01'
      ,'0.01'
      ,'0'
      ,'0'
      ,'0'
      ,'10'
      ,'0'
      ,'0.2'
      ,'0.38'
      ,'0.25'
      ,'0.75'
      ,'0.01'
      ,'0.03'
      ,'0'
      ,'0'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13'
      ,'SSSHBG_20251203_1_0606_1'
      ,'13'
      ,'0.1'
      ,'0.25'
      ,'0.01'
      ,'0.02'
      ,'0'
      ,'0'
      ,'0'
      ,'78'
      ,'18'
      ,'0.1'
      ,'0.21'
      ,'0'
      ,'0'
      ,'0'
      ,'0'
      ,'0'
      ,'0'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_14'
      ,'SSSHBG_20251203_1_0606_1'
      ,'14'
      ,'0.1'
      ,'0.27'
      ,'0.01'
      ,'0.01'
      ,'0'
      ,'0'
      ,'0.01'
      ,'7'
      ,'0'
      ,'0.01'
      ,'0.04'
      ,'0.1'
      ,'0.19'
      ,'0.01'
      ,'0.06'
      ,'0'
      ,'0'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


INSERT INTO [dbo].[ShellBudgetQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[TotalSampleVolume]
           ,[TotalSampleWeight]
           ,[LiveOysterVolume]
           ,[LiveOysterWeight]
           ,[NumDrills]
           ,[DrillWeight]
           ,[OtherBiotaWeight]
           ,[NumLiveOysters]
           ,[NumDeadOysters]
           ,[OysterShellVolume]
           ,[OysterShellWeight]
           ,[PlantedShellVolume]
           ,[PlantedShellWeight]
           ,[ShellHashVolume]
           ,[ShellHashWeight]
           ,[BlackAndOtherSubstrateVolume]
           ,[BlackAndOtherSubstrateWeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_15'
      ,'SSSHBG_20251203_1_0606_1'
      ,'15'
      ,'0.15'
      ,'0.27'
      ,'0'
      ,'0'
      ,'0'
      ,'0'
      ,'0'
      ,'0'
      ,'3'
      ,'0.05'
      ,'0.09'
      ,'0.1'
      ,'0.15'
      ,'0.01'
      ,'0.03'
      ,'0'
      ,'0'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_01_001'
      ,'SSSHBG_20251203_1_0603_1_01'
      ,'Live'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_01_002'
      ,'SSSHBG_20251203_1_0603_1_01'
      ,'Live'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_01_003'
      ,'SSSHBG_20251203_1_0603_1_01'
      ,'Live'
      ,'13'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_01_004'
      ,'SSSHBG_20251203_1_0603_1_01'
      ,'Live'
      ,'6'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_01_005'
      ,'SSSHBG_20251203_1_0603_1_01'
      ,'Live'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_01_006'
      ,'SSSHBG_20251203_1_0603_1_01'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_01_007'
      ,'SSSHBG_20251203_1_0603_1_01'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_01_008'
      ,'SSSHBG_20251203_1_0603_1_01'
      ,'Live'
      ,'14'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_02_001'
      ,'SSSHBG_20251203_1_0603_1_02'
      ,'Live'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_03_001'
      ,'SSSHBG_20251203_1_0603_1_03'
      ,'Live'
      ,'19'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_03_002'
      ,'SSSHBG_20251203_1_0603_1_03'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_03_003'
      ,'SSSHBG_20251203_1_0603_1_03'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_03_004'
      ,'SSSHBG_20251203_1_0603_1_03'
      ,'Live'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_03_005'
      ,'SSSHBG_20251203_1_0603_1_03'
      ,'Live'
      ,'18'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_03_006'
      ,'SSSHBG_20251203_1_0603_1_03'
      ,'Live'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_03_007'
      ,'SSSHBG_20251203_1_0603_1_03'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_03_008'
      ,'SSSHBG_20251203_1_0603_1_03'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_03_009'
      ,'SSSHBG_20251203_1_0603_1_03'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_04_001'
      ,'SSSHBG_20251203_1_0603_1_04'
      ,'Live'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_04_002'
      ,'SSSHBG_20251203_1_0603_1_04'
      ,'Live'
      ,'6'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_04_003'
      ,'SSSHBG_20251203_1_0603_1_04'
      ,'Live'
      ,'9'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_04_004'
      ,'SSSHBG_20251203_1_0603_1_04'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_06_001'
      ,'SSSHBG_20251203_1_0603_1_06'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_06_002'
      ,'SSSHBG_20251203_1_0603_1_06'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_06_003'
      ,'SSSHBG_20251203_1_0603_1_06'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_06_004'
      ,'SSSHBG_20251203_1_0603_1_06'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_06_005'
      ,'SSSHBG_20251203_1_0603_1_06'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_06_006'
      ,'SSSHBG_20251203_1_0603_1_06'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_06_007'
      ,'SSSHBG_20251203_1_0603_1_06'
      ,'Live'
      ,'6'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_06_008'
      ,'SSSHBG_20251203_1_0603_1_06'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_06_009'
      ,'SSSHBG_20251203_1_0603_1_06'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_06_010'
      ,'SSSHBG_20251203_1_0603_1_06'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_06_011'
      ,'SSSHBG_20251203_1_0603_1_06'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_06_012'
      ,'SSSHBG_20251203_1_0603_1_06'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_06_013'
      ,'SSSHBG_20251203_1_0603_1_06'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_06_014'
      ,'SSSHBG_20251203_1_0603_1_06'
      ,'Live'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_06_015'
      ,'SSSHBG_20251203_1_0603_1_06'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_06_016'
      ,'SSSHBG_20251203_1_0603_1_06'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_06_017'
      ,'SSSHBG_20251203_1_0603_1_06'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_06_018'
      ,'SSSHBG_20251203_1_0603_1_06'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_06_019'
      ,'SSSHBG_20251203_1_0603_1_06'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_06_020'
      ,'SSSHBG_20251203_1_0603_1_06'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_07_001'
      ,'SSSHBG_20251203_1_0603_1_07'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_07_002'
      ,'SSSHBG_20251203_1_0603_1_07'
      ,'Live'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_07_003'
      ,'SSSHBG_20251203_1_0603_1_07'
      ,'Live'
      ,'13'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_07_004'
      ,'SSSHBG_20251203_1_0603_1_07'
      ,'Live'
      ,'17'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_07_005'
      ,'SSSHBG_20251203_1_0603_1_07'
      ,'Live'
      ,'9'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_08_001'
      ,'SSSHBG_20251203_1_0603_1_08'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_08_002'
      ,'SSSHBG_20251203_1_0603_1_08'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_08_003'
      ,'SSSHBG_20251203_1_0603_1_08'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_08_004'
      ,'SSSHBG_20251203_1_0603_1_08'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_08_005'
      ,'SSSHBG_20251203_1_0603_1_08'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_08_006'
      ,'SSSHBG_20251203_1_0603_1_08'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_09_001'
      ,'SSSHBG_20251203_1_0603_1_09'
      ,'Live'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_09_002'
      ,'SSSHBG_20251203_1_0603_1_09'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_09_003'
      ,'SSSHBG_20251203_1_0603_1_09'
      ,'Live'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_09_004'
      ,'SSSHBG_20251203_1_0603_1_09'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_09_005'
      ,'SSSHBG_20251203_1_0603_1_09'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_11_001'
      ,'SSSHBG_20251203_1_0603_1_11'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_11_002'
      ,'SSSHBG_20251203_1_0603_1_11'
      ,'Dead'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_11_003'
      ,'SSSHBG_20251203_1_0603_1_11'
      ,'Dead'
      ,'44'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_11_004'
      ,'SSSHBG_20251203_1_0603_1_11'
      ,'Dead'
      ,'75'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_11_005'
      ,'SSSHBG_20251203_1_0603_1_11'
      ,'Dead'
      ,'17'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_11_006'
      ,'SSSHBG_20251203_1_0603_1_11'
      ,'Dead'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_12_001'
      ,'SSSHBG_20251203_1_0603_1_12'
      ,'Dead'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_12_002'
      ,'SSSHBG_20251203_1_0603_1_12'
      ,'Dead'
      ,'13'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_12_003'
      ,'SSSHBG_20251203_1_0603_1_12'
      ,'Dead'
      ,'25'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_12_004'
      ,'SSSHBG_20251203_1_0603_1_12'
      ,'Dead'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_13_001'
      ,'SSSHBG_20251203_1_0603_1_13'
      ,'Live'
      ,'9'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_13_002'
      ,'SSSHBG_20251203_1_0603_1_13'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_13_003'
      ,'SSSHBG_20251203_1_0603_1_13'
      ,'Live'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_13_004'
      ,'SSSHBG_20251203_1_0603_1_13'
      ,'Dead'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_14_001'
      ,'SSSHBG_20251203_1_0603_1_14'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_14_002'
      ,'SSSHBG_20251203_1_0603_1_14'
      ,'Live'
      ,'13'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_14_003'
      ,'SSSHBG_20251203_1_0603_1_14'
      ,'Live'
      ,'13'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_14_004'
      ,'SSSHBG_20251203_1_0603_1_14'
      ,'Live'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_14_005'
      ,'SSSHBG_20251203_1_0603_1_14'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_14_006'
      ,'SSSHBG_20251203_1_0603_1_14'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_14_007'
      ,'SSSHBG_20251203_1_0603_1_14'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_14_008'
      ,'SSSHBG_20251203_1_0603_1_14'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_14_009'
      ,'SSSHBG_20251203_1_0603_1_14'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_14_010'
      ,'SSSHBG_20251203_1_0603_1_14'
      ,'Dead'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_14_011'
      ,'SSSHBG_20251203_1_0603_1_14'
      ,'Dead'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_14_012'
      ,'SSSHBG_20251203_1_0603_1_14'
      ,'Dead'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_14_013'
      ,'SSSHBG_20251203_1_0603_1_14'
      ,'Dead'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_14_014'
      ,'SSSHBG_20251203_1_0603_1_14'
      ,'Dead'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_14_015'
      ,'SSSHBG_20251203_1_0603_1_14'
      ,'Dead'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_14_016'
      ,'SSSHBG_20251203_1_0603_1_14'
      ,'Dead'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_14_017'
      ,'SSSHBG_20251203_1_0603_1_14'
      ,'Dead'
      ,'13'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_14_018'
      ,'SSSHBG_20251203_1_0603_1_14'
      ,'Dead'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_14_019'
      ,'SSSHBG_20251203_1_0603_1_14'
      ,'Dead'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_14_020'
      ,'SSSHBG_20251203_1_0603_1_14'
      ,'Dead'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_14_021'
      ,'SSSHBG_20251203_1_0603_1_14'
      ,'Dead'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_14_022'
      ,'SSSHBG_20251203_1_0603_1_14'
      ,'Dead'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_14_023'
      ,'SSSHBG_20251203_1_0603_1_14'
      ,'Dead'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_14_024'
      ,'SSSHBG_20251203_1_0603_1_14'
      ,'Dead'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_14_025'
      ,'SSSHBG_20251203_1_0603_1_14'
      ,'Dead'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_14_026'
      ,'SSSHBG_20251203_1_0603_1_14'
      ,'Dead'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_14_027'
      ,'SSSHBG_20251203_1_0603_1_14'
      ,'Dead'
      ,'13'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_14_028'
      ,'SSSHBG_20251203_1_0603_1_14'
      ,'Dead'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_14_029'
      ,'SSSHBG_20251203_1_0603_1_14'
      ,'Dead'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_14_030'
      ,'SSSHBG_20251203_1_0603_1_14'
      ,'Dead'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_14_031'
      ,'SSSHBG_20251203_1_0603_1_14'
      ,'Dead'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_15_001'
      ,'SSSHBG_20251203_1_0603_1_15'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_15_002'
      ,'SSSHBG_20251203_1_0603_1_15'
      ,'Live'
      ,'13'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0603_1_15_003'
      ,'SSSHBG_20251203_1_0603_1_15'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_01_001'
      ,'SSSHBG_20251203_1_0604_1_01'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_01_002'
      ,'SSSHBG_20251203_1_0604_1_01'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_01_003'
      ,'SSSHBG_20251203_1_0604_1_01'
      ,'Live'
      ,'6'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_01_004'
      ,'SSSHBG_20251203_1_0604_1_01'
      ,'Live'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_01_005'
      ,'SSSHBG_20251203_1_0604_1_01'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_01_006'
      ,'SSSHBG_20251203_1_0604_1_01'
      ,'Live'
      ,'6'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_01_007'
      ,'SSSHBG_20251203_1_0604_1_01'
      ,'Live'
      ,'6'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_01_008'
      ,'SSSHBG_20251203_1_0604_1_01'
      ,'Live'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_01_009'
      ,'SSSHBG_20251203_1_0604_1_01'
      ,'Live'
      ,'14'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_01_010'
      ,'SSSHBG_20251203_1_0604_1_01'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_01_011'
      ,'SSSHBG_20251203_1_0604_1_01'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_01_012'
      ,'SSSHBG_20251203_1_0604_1_01'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_01_013'
      ,'SSSHBG_20251203_1_0604_1_01'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_01_014'
      ,'SSSHBG_20251203_1_0604_1_01'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_01_015'
      ,'SSSHBG_20251203_1_0604_1_01'
      ,'Live'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_01_016'
      ,'SSSHBG_20251203_1_0604_1_01'
      ,'Live'
      ,'6'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_01_017'
      ,'SSSHBG_20251203_1_0604_1_01'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_01_018'
      ,'SSSHBG_20251203_1_0604_1_01'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_02_001'
      ,'SSSHBG_20251203_1_0604_1_02'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_02_002'
      ,'SSSHBG_20251203_1_0604_1_02'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_02_003'
      ,'SSSHBG_20251203_1_0604_1_02'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_02_004'
      ,'SSSHBG_20251203_1_0604_1_02'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_02_005'
      ,'SSSHBG_20251203_1_0604_1_02'
      ,'Live'
      ,'14'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_02_006'
      ,'SSSHBG_20251203_1_0604_1_02'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_02_007'
      ,'SSSHBG_20251203_1_0604_1_02'
      ,'Live'
      ,'16'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_02_008'
      ,'SSSHBG_20251203_1_0604_1_02'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_02_009'
      ,'SSSHBG_20251203_1_0604_1_02'
      ,'Live'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_02_010'
      ,'SSSHBG_20251203_1_0604_1_02'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_02_011'
      ,'SSSHBG_20251203_1_0604_1_02'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_02_012'
      ,'SSSHBG_20251203_1_0604_1_02'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_02_013'
      ,'SSSHBG_20251203_1_0604_1_02'
      ,'Live'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_02_014'
      ,'SSSHBG_20251203_1_0604_1_02'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_02_015'
      ,'SSSHBG_20251203_1_0604_1_02'
      ,'Live'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_03_001'
      ,'SSSHBG_20251203_1_0604_1_03'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_03_002'
      ,'SSSHBG_20251203_1_0604_1_03'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_04_001'
      ,'SSSHBG_20251203_1_0604_1_04'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_04_002'
      ,'SSSHBG_20251203_1_0604_1_04'
      ,'Live'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_04_003'
      ,'SSSHBG_20251203_1_0604_1_04'
      ,'Live'
      ,'30'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_05_001'
      ,'SSSHBG_20251203_1_0604_1_05'
      ,'Live'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_05_002'
      ,'SSSHBG_20251203_1_0604_1_05'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_05_003'
      ,'SSSHBG_20251203_1_0604_1_05'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_05_004'
      ,'SSSHBG_20251203_1_0604_1_05'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_05_005'
      ,'SSSHBG_20251203_1_0604_1_05'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_05_006'
      ,'SSSHBG_20251203_1_0604_1_05'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_05_007'
      ,'SSSHBG_20251203_1_0604_1_05'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_07_001'
      ,'SSSHBG_20251203_1_0604_1_07'
      ,'Live'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_07_002'
      ,'SSSHBG_20251203_1_0604_1_07'
      ,'Live'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_07_003'
      ,'SSSHBG_20251203_1_0604_1_07'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_07_004'
      ,'SSSHBG_20251203_1_0604_1_07'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_07_005'
      ,'SSSHBG_20251203_1_0604_1_07'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_07_006'
      ,'SSSHBG_20251203_1_0604_1_07'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_06_001'
      ,'SSSHBG_20251203_1_0604_1_06'
      ,'Live'
      ,'6'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_08_001'
      ,'SSSHBG_20251203_1_0604_1_08'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_08_002'
      ,'SSSHBG_20251203_1_0604_1_08'
      ,'Live'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_08_003'
      ,'SSSHBG_20251203_1_0604_1_08'
      ,'Live'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_08_004'
      ,'SSSHBG_20251203_1_0604_1_08'
      ,'Live'
      ,'14'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_08_005'
      ,'SSSHBG_20251203_1_0604_1_08'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_08_006'
      ,'SSSHBG_20251203_1_0604_1_08'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_08_007'
      ,'SSSHBG_20251203_1_0604_1_08'
      ,'Live'
      ,'9'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_08_008'
      ,'SSSHBG_20251203_1_0604_1_08'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_08_009'
      ,'SSSHBG_20251203_1_0604_1_08'
      ,'Live'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_08_010'
      ,'SSSHBG_20251203_1_0604_1_08'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_08_011'
      ,'SSSHBG_20251203_1_0604_1_08'
      ,'Live'
      ,'9'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_08_012'
      ,'SSSHBG_20251203_1_0604_1_08'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_08_013'
      ,'SSSHBG_20251203_1_0604_1_08'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_08_014'
      ,'SSSHBG_20251203_1_0604_1_08'
      ,'Live'
      ,'16'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_08_015'
      ,'SSSHBG_20251203_1_0604_1_08'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_08_016'
      ,'SSSHBG_20251203_1_0604_1_08'
      ,'Live'
      ,'6'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_08_017'
      ,'SSSHBG_20251203_1_0604_1_08'
      ,'Live'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_09_001'
      ,'SSSHBG_20251203_1_0604_1_09'
      ,'Live'
      ,'19'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_09_002'
      ,'SSSHBG_20251203_1_0604_1_09'
      ,'Live'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_09_003'
      ,'SSSHBG_20251203_1_0604_1_09'
      ,'Live'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_09_004'
      ,'SSSHBG_20251203_1_0604_1_09'
      ,'Live'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_09_005'
      ,'SSSHBG_20251203_1_0604_1_09'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_09_006'
      ,'SSSHBG_20251203_1_0604_1_09'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_09_007'
      ,'SSSHBG_20251203_1_0604_1_09'
      ,'Live'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_09_008'
      ,'SSSHBG_20251203_1_0604_1_09'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_09_009'
      ,'SSSHBG_20251203_1_0604_1_09'
      ,'Live'
      ,'13'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_09_010'
      ,'SSSHBG_20251203_1_0604_1_09'
      ,'Live'
      ,'9'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_09_011'
      ,'SSSHBG_20251203_1_0604_1_09'
      ,'Live'
      ,'6'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_09_012'
      ,'SSSHBG_20251203_1_0604_1_09'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_09_013'
      ,'SSSHBG_20251203_1_0604_1_09'
      ,'Live'
      ,'9'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_09_014'
      ,'SSSHBG_20251203_1_0604_1_09'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_09_015'
      ,'SSSHBG_20251203_1_0604_1_09'
      ,'Live'
      ,'13'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_09_016'
      ,'SSSHBG_20251203_1_0604_1_09'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_09_017'
      ,'SSSHBG_20251203_1_0604_1_09'
      ,'Live'
      ,'9'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_09_018'
      ,'SSSHBG_20251203_1_0604_1_09'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_09_019'
      ,'SSSHBG_20251203_1_0604_1_09'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_09_020'
      ,'SSSHBG_20251203_1_0604_1_09'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_09_021'
      ,'SSSHBG_20251203_1_0604_1_09'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_09_022'
      ,'SSSHBG_20251203_1_0604_1_09'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_09_023'
      ,'SSSHBG_20251203_1_0604_1_09'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_10_001'
      ,'SSSHBG_20251203_1_0604_1_10'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_10_002'
      ,'SSSHBG_20251203_1_0604_1_10'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_10_003'
      ,'SSSHBG_20251203_1_0604_1_10'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_10_004'
      ,'SSSHBG_20251203_1_0604_1_10'
      ,'Live'
      ,'6'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_10_005'
      ,'SSSHBG_20251203_1_0604_1_10'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_10_006'
      ,'SSSHBG_20251203_1_0604_1_10'
      ,'Live'
      ,'6'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_10_007'
      ,'SSSHBG_20251203_1_0604_1_10'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_10_008'
      ,'SSSHBG_20251203_1_0604_1_10'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_10_009'
      ,'SSSHBG_20251203_1_0604_1_10'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_11_001'
      ,'SSSHBG_20251203_1_0604_1_11'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_11_002'
      ,'SSSHBG_20251203_1_0604_1_11'
      ,'Live'
      ,'9'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_11_003'
      ,'SSSHBG_20251203_1_0604_1_11'
      ,'Live'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_11_004'
      ,'SSSHBG_20251203_1_0604_1_11'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_11_005'
      ,'SSSHBG_20251203_1_0604_1_11'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_11_006'
      ,'SSSHBG_20251203_1_0604_1_11'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_11_007'
      ,'SSSHBG_20251203_1_0604_1_11'
      ,'Live'
      ,'9'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_11_008'
      ,'SSSHBG_20251203_1_0604_1_11'
      ,'Live'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_11_009'
      ,'SSSHBG_20251203_1_0604_1_11'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_11_010'
      ,'SSSHBG_20251203_1_0604_1_11'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_11_011'
      ,'SSSHBG_20251203_1_0604_1_11'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_11_012'
      ,'SSSHBG_20251203_1_0604_1_11'
      ,'Dead'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_001'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Live'
      ,'6'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_002'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_003'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_004'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_005'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_006'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_007'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_008'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Live'
      ,'9'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_009'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_010'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_011'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Live'
      ,'16'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_012'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Live'
      ,'13'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_013'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_014'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Live'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_015'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_016'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_017'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Live'
      ,'6'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_018'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Live'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_019'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_020'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_021'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_022'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Live'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_023'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Live'
      ,'9'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_024'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_025'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_026'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_027'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_028'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Live'
      ,'19'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_029'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Live'
      ,'9'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_030'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Live'
      ,'17'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_031'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_032'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_033'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Dead'
      ,'19'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_034'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Dead'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_035'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Dead'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_036'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Dead'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_037'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Dead'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_038'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Dead'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_039'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Dead'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_040'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Dead'
      ,'21'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_041'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Dead'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_042'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Dead'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_043'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Dead'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_044'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Dead'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_045'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Dead'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_046'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Dead'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_047'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Dead'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_048'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Dead'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_049'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Dead'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_12_050'
      ,'SSSHBG_20251203_1_0604_1_12'
      ,'Dead'
      ,'14'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_13_001'
      ,'SSSHBG_20251203_1_0604_1_13'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_13_002'
      ,'SSSHBG_20251203_1_0604_1_13'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_13_003'
      ,'SSSHBG_20251203_1_0604_1_13'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_13_004'
      ,'SSSHBG_20251203_1_0604_1_13'
      ,'Live'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_13_005'
      ,'SSSHBG_20251203_1_0604_1_13'
      ,'Live'
      ,'9'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_13_006'
      ,'SSSHBG_20251203_1_0604_1_13'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_13_007'
      ,'SSSHBG_20251203_1_0604_1_13'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_13_008'
      ,'SSSHBG_20251203_1_0604_1_13'
      ,'Live'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_13_009'
      ,'SSSHBG_20251203_1_0604_1_13'
      ,'Live'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_13_010'
      ,'SSSHBG_20251203_1_0604_1_13'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_13_011'
      ,'SSSHBG_20251203_1_0604_1_13'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_13_012'
      ,'SSSHBG_20251203_1_0604_1_13'
      ,'Live'
      ,'6'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_13_013'
      ,'SSSHBG_20251203_1_0604_1_13'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_13_014'
      ,'SSSHBG_20251203_1_0604_1_13'
      ,'Live'
      ,'16'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_13_015'
      ,'SSSHBG_20251203_1_0604_1_13'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_13_016'
      ,'SSSHBG_20251203_1_0604_1_13'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_13_017'
      ,'SSSHBG_20251203_1_0604_1_13'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_13_018'
      ,'SSSHBG_20251203_1_0604_1_13'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_13_019'
      ,'SSSHBG_20251203_1_0604_1_13'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_13_020'
      ,'SSSHBG_20251203_1_0604_1_13'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_13_021'
      ,'SSSHBG_20251203_1_0604_1_13'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_13_022'
      ,'SSSHBG_20251203_1_0604_1_13'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_13_023'
      ,'SSSHBG_20251203_1_0604_1_13'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_13_024'
      ,'SSSHBG_20251203_1_0604_1_13'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_13_025'
      ,'SSSHBG_20251203_1_0604_1_13'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_13_026'
      ,'SSSHBG_20251203_1_0604_1_13'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_13_027'
      ,'SSSHBG_20251203_1_0604_1_13'
      ,'Live'
      ,'9'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_13_028'
      ,'SSSHBG_20251203_1_0604_1_13'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_13_029'
      ,'SSSHBG_20251203_1_0604_1_13'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_13_030'
      ,'SSSHBG_20251203_1_0604_1_13'
      ,'Live'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_13_031'
      ,'SSSHBG_20251203_1_0604_1_13'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_13_032'
      ,'SSSHBG_20251203_1_0604_1_13'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_13_033'
      ,'SSSHBG_20251203_1_0604_1_13'
      ,'Live'
      ,'13'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_13_034'
      ,'SSSHBG_20251203_1_0604_1_13'
      ,'Dead'
      ,'17'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_13_035'
      ,'SSSHBG_20251203_1_0604_1_13'
      ,'Dead'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_13_036'
      ,'SSSHBG_20251203_1_0604_1_13'
      ,'Dead'
      ,'13'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_13_037'
      ,'SSSHBG_20251203_1_0604_1_13'
      ,'Dead'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_13_038'
      ,'SSSHBG_20251203_1_0604_1_13'
      ,'Dead'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_13_039'
      ,'SSSHBG_20251203_1_0604_1_13'
      ,'Dead'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_13_040'
      ,'SSSHBG_20251203_1_0604_1_13'
      ,'Dead'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_13_041'
      ,'SSSHBG_20251203_1_0604_1_13'
      ,'Dead'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_13_042'
      ,'SSSHBG_20251203_1_0604_1_13'
      ,'Dead'
      ,'13'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_15_001'
      ,'SSSHBG_20251203_1_0604_1_15'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_15_002'
      ,'SSSHBG_20251203_1_0604_1_15'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_15_003'
      ,'SSSHBG_20251203_1_0604_1_15'
      ,'Live'
      ,'22'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_15_004'
      ,'SSSHBG_20251203_1_0604_1_15'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_15_005'
      ,'SSSHBG_20251203_1_0604_1_15'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_15_006'
      ,'SSSHBG_20251203_1_0604_1_15'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_15_007'
      ,'SSSHBG_20251203_1_0604_1_15'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_15_008'
      ,'SSSHBG_20251203_1_0604_1_15'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_15_009'
      ,'SSSHBG_20251203_1_0604_1_15'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_15_010'
      ,'SSSHBG_20251203_1_0604_1_15'
      ,'Live'
      ,'13'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_15_011'
      ,'SSSHBG_20251203_1_0604_1_15'
      ,'Live'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_15_012'
      ,'SSSHBG_20251203_1_0604_1_15'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_15_013'
      ,'SSSHBG_20251203_1_0604_1_15'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_15_014'
      ,'SSSHBG_20251203_1_0604_1_15'
      ,'Live'
      ,'13'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0604_1_15_015'
      ,'SSSHBG_20251203_1_0604_1_15'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_01_001'
      ,'SSSHBG_20251203_1_0605_1_01'
      ,'Live'
      ,'18'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_01_002'
      ,'SSSHBG_20251203_1_0605_1_01'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_01_003'
      ,'SSSHBG_20251203_1_0605_1_01'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_01_004'
      ,'SSSHBG_20251203_1_0605_1_01'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_01_005'
      ,'SSSHBG_20251203_1_0605_1_01'
      ,'Live'
      ,'13'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_01_006'
      ,'SSSHBG_20251203_1_0605_1_01'
      ,'Live'
      ,'14'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_01_007'
      ,'SSSHBG_20251203_1_0605_1_01'
      ,'Live'
      ,'9'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_01_008'
      ,'SSSHBG_20251203_1_0605_1_01'
      ,'Live'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_02_001'
      ,'SSSHBG_20251203_1_0605_1_02'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_02_002'
      ,'SSSHBG_20251203_1_0605_1_02'
      ,'Live'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_02_003'
      ,'SSSHBG_20251203_1_0605_1_02'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_02_004'
      ,'SSSHBG_20251203_1_0605_1_02'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_02_005'
      ,'SSSHBG_20251203_1_0605_1_02'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_02_006'
      ,'SSSHBG_20251203_1_0605_1_02'
      ,'Live'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_02_007'
      ,'SSSHBG_20251203_1_0605_1_02'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_02_008'
      ,'SSSHBG_20251203_1_0605_1_02'
      ,'Live'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_04_001'
      ,'SSSHBG_20251203_1_0605_1_04'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_04_002'
      ,'SSSHBG_20251203_1_0605_1_04'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_04_003'
      ,'SSSHBG_20251203_1_0605_1_04'
      ,'Live'
      ,'25'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_04_004'
      ,'SSSHBG_20251203_1_0605_1_04'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_04_005'
      ,'SSSHBG_20251203_1_0605_1_04'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_04_006'
      ,'SSSHBG_20251203_1_0605_1_04'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_04_007'
      ,'SSSHBG_20251203_1_0605_1_04'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_03_001'
      ,'SSSHBG_20251203_1_0605_1_03'
      ,'Live'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_03_002'
      ,'SSSHBG_20251203_1_0605_1_03'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_03_003'
      ,'SSSHBG_20251203_1_0605_1_03'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_03_004'
      ,'SSSHBG_20251203_1_0605_1_03'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_05_001'
      ,'SSSHBG_20251203_1_0605_1_05'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_05_002'
      ,'SSSHBG_20251203_1_0605_1_05'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_05_003'
      ,'SSSHBG_20251203_1_0605_1_05'
      ,'Live'
      ,'18'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_05_004'
      ,'SSSHBG_20251203_1_0605_1_05'
      ,'Live'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_05_005'
      ,'SSSHBG_20251203_1_0605_1_05'
      ,'Live'
      ,'14'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_05_006'
      ,'SSSHBG_20251203_1_0605_1_05'
      ,'Live'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_05_007'
      ,'SSSHBG_20251203_1_0605_1_05'
      ,'Live'
      ,'19'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_05_008'
      ,'SSSHBG_20251203_1_0605_1_05'
      ,'Live'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_05_009'
      ,'SSSHBG_20251203_1_0605_1_05'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_05_010'
      ,'SSSHBG_20251203_1_0605_1_05'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_05_011'
      ,'SSSHBG_20251203_1_0605_1_05'
      ,'Live'
      ,'21'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_05_012'
      ,'SSSHBG_20251203_1_0605_1_05'
      ,'Live'
      ,'21'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_05_013'
      ,'SSSHBG_20251203_1_0605_1_05'
      ,'Live'
      ,'18'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_05_014'
      ,'SSSHBG_20251203_1_0605_1_05'
      ,'Live'
      ,'16'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_05_015'
      ,'SSSHBG_20251203_1_0605_1_05'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_05_016'
      ,'SSSHBG_20251203_1_0605_1_05'
      ,'Live'
      ,'6'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_05_017'
      ,'SSSHBG_20251203_1_0605_1_05'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_05_018'
      ,'SSSHBG_20251203_1_0605_1_05'
      ,'Live'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_05_019'
      ,'SSSHBG_20251203_1_0605_1_05'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_07_001'
      ,'SSSHBG_20251203_1_0605_1_07'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_07_002'
      ,'SSSHBG_20251203_1_0605_1_07'
      ,'Live'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_07_003'
      ,'SSSHBG_20251203_1_0605_1_07'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_06_001'
      ,'SSSHBG_20251203_1_0605_1_06'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_06_002'
      ,'SSSHBG_20251203_1_0605_1_06'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_06_003'
      ,'SSSHBG_20251203_1_0605_1_06'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_06_004'
      ,'SSSHBG_20251203_1_0605_1_06'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_06_005'
      ,'SSSHBG_20251203_1_0605_1_06'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_06_006'
      ,'SSSHBG_20251203_1_0605_1_06'
      ,'Live'
      ,'2'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_06_007'
      ,'SSSHBG_20251203_1_0605_1_06'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_08_001'
      ,'SSSHBG_20251203_1_0605_1_08'
      ,'Live'
      ,'17'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_08_002'
      ,'SSSHBG_20251203_1_0605_1_08'
      ,'Live'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_08_003'
      ,'SSSHBG_20251203_1_0605_1_08'
      ,'Live'
      ,'38'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_08_004'
      ,'SSSHBG_20251203_1_0605_1_08'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_08_005'
      ,'SSSHBG_20251203_1_0605_1_08'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_08_006'
      ,'SSSHBG_20251203_1_0605_1_08'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_08_007'
      ,'SSSHBG_20251203_1_0605_1_08'
      ,'Live'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_08_008'
      ,'SSSHBG_20251203_1_0605_1_08'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_08_009'
      ,'SSSHBG_20251203_1_0605_1_08'
      ,'Live'
      ,'9'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_08_010'
      ,'SSSHBG_20251203_1_0605_1_08'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_08_011'
      ,'SSSHBG_20251203_1_0605_1_08'
      ,'Live'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_08_012'
      ,'SSSHBG_20251203_1_0605_1_08'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_08_013'
      ,'SSSHBG_20251203_1_0605_1_08'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_08_014'
      ,'SSSHBG_20251203_1_0605_1_08'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_08_015'
      ,'SSSHBG_20251203_1_0605_1_08'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_08_016'
      ,'SSSHBG_20251203_1_0605_1_08'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_08_017'
      ,'SSSHBG_20251203_1_0605_1_08'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_08_018'
      ,'SSSHBG_20251203_1_0605_1_08'
      ,'Live'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_08_019'
      ,'SSSHBG_20251203_1_0605_1_08'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_08_020'
      ,'SSSHBG_20251203_1_0605_1_08'
      ,'Live'
      ,'9'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_08_021'
      ,'SSSHBG_20251203_1_0605_1_08'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_09_001'
      ,'SSSHBG_20251203_1_0605_1_09'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_09_002'
      ,'SSSHBG_20251203_1_0605_1_09'
      ,'Live'
      ,'14'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_09_003'
      ,'SSSHBG_20251203_1_0605_1_09'
      ,'Live'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_09_004'
      ,'SSSHBG_20251203_1_0605_1_09'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_09_005'
      ,'SSSHBG_20251203_1_0605_1_09'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_09_006'
      ,'SSSHBG_20251203_1_0605_1_09'
      ,'Live'
      ,'9'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_09_007'
      ,'SSSHBG_20251203_1_0605_1_09'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_09_008'
      ,'SSSHBG_20251203_1_0605_1_09'
      ,'Live'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_09_009'
      ,'SSSHBG_20251203_1_0605_1_09'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_09_010'
      ,'SSSHBG_20251203_1_0605_1_09'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_09_011'
      ,'SSSHBG_20251203_1_0605_1_09'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_09_012'
      ,'SSSHBG_20251203_1_0605_1_09'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_09_013'
      ,'SSSHBG_20251203_1_0605_1_09'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_09_014'
      ,'SSSHBG_20251203_1_0605_1_09'
      ,'Live'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_09_015'
      ,'SSSHBG_20251203_1_0605_1_09'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_09_016'
      ,'SSSHBG_20251203_1_0605_1_09'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_09_017'
      ,'SSSHBG_20251203_1_0605_1_09'
      ,'Live'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_09_018'
      ,'SSSHBG_20251203_1_0605_1_09'
      ,'Live'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_09_019'
      ,'SSSHBG_20251203_1_0605_1_09'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_09_020'
      ,'SSSHBG_20251203_1_0605_1_09'
      ,'Live'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_09_021'
      ,'SSSHBG_20251203_1_0605_1_09'
      ,'Live'
      ,'16'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_09_022'
      ,'SSSHBG_20251203_1_0605_1_09'
      ,'Live'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_09_023'
      ,'SSSHBG_20251203_1_0605_1_09'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_09_024'
      ,'SSSHBG_20251203_1_0605_1_09'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_09_025'
      ,'SSSHBG_20251203_1_0605_1_09'
      ,'Live'
      ,'9'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_09_026'
      ,'SSSHBG_20251203_1_0605_1_09'
      ,'Live'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_09_027'
      ,'SSSHBG_20251203_1_0605_1_09'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_09_028'
      ,'SSSHBG_20251203_1_0605_1_09'
      ,'Live'
      ,'6'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_09_029'
      ,'SSSHBG_20251203_1_0605_1_09'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_09_030'
      ,'SSSHBG_20251203_1_0605_1_09'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_10_001'
      ,'SSSHBG_20251203_1_0605_1_10'
      ,'Live'
      ,'27'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_10_002'
      ,'SSSHBG_20251203_1_0605_1_10'
      ,'Live'
      ,'22'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_10_003'
      ,'SSSHBG_20251203_1_0605_1_10'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_10_004'
      ,'SSSHBG_20251203_1_0605_1_10'
      ,'Live'
      ,'19'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_10_005'
      ,'SSSHBG_20251203_1_0605_1_10'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_10_006'
      ,'SSSHBG_20251203_1_0605_1_10'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_10_007'
      ,'SSSHBG_20251203_1_0605_1_10'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_10_008'
      ,'SSSHBG_20251203_1_0605_1_10'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_10_009'
      ,'SSSHBG_20251203_1_0605_1_10'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_10_010'
      ,'SSSHBG_20251203_1_0605_1_10'
      ,'Live'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_10_011'
      ,'SSSHBG_20251203_1_0605_1_10'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_10_012'
      ,'SSSHBG_20251203_1_0605_1_10'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_10_013'
      ,'SSSHBG_20251203_1_0605_1_10'
      ,'Live'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_10_014'
      ,'SSSHBG_20251203_1_0605_1_10'
      ,'Live'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_10_015'
      ,'SSSHBG_20251203_1_0605_1_10'
      ,'Live'
      ,'13'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_10_016'
      ,'SSSHBG_20251203_1_0605_1_10'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_10_017'
      ,'SSSHBG_20251203_1_0605_1_10'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_10_018'
      ,'SSSHBG_20251203_1_0605_1_10'
      ,'Live'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_10_019'
      ,'SSSHBG_20251203_1_0605_1_10'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_10_020'
      ,'SSSHBG_20251203_1_0605_1_10'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_10_021'
      ,'SSSHBG_20251203_1_0605_1_10'
      ,'Live'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_10_022'
      ,'SSSHBG_20251203_1_0605_1_10'
      ,'Live'
      ,'9'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_10_023'
      ,'SSSHBG_20251203_1_0605_1_10'
      ,'Live'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_10_024'
      ,'SSSHBG_20251203_1_0605_1_10'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_10_025'
      ,'SSSHBG_20251203_1_0605_1_10'
      ,'Live'
      ,'6'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_10_026'
      ,'SSSHBG_20251203_1_0605_1_10'
      ,'Live'
      ,'6'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_10_027'
      ,'SSSHBG_20251203_1_0605_1_10'
      ,'Live'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_10_028'
      ,'SSSHBG_20251203_1_0605_1_10'
      ,'Live'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_10_029'
      ,'SSSHBG_20251203_1_0605_1_10'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_10_030'
      ,'SSSHBG_20251203_1_0605_1_10'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_10_031'
      ,'SSSHBG_20251203_1_0605_1_10'
      ,'Live'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_10_032'
      ,'SSSHBG_20251203_1_0605_1_10'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_10_033'
      ,'SSSHBG_20251203_1_0605_1_10'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_10_034'
      ,'SSSHBG_20251203_1_0605_1_10'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_10_035'
      ,'SSSHBG_20251203_1_0605_1_10'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_10_036'
      ,'SSSHBG_20251203_1_0605_1_10'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_10_037'
      ,'SSSHBG_20251203_1_0605_1_10'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_12_001'
      ,'SSSHBG_20251203_1_0605_1_12'
      ,'Live'
      ,'16'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_12_002'
      ,'SSSHBG_20251203_1_0605_1_12'
      ,'Live'
      ,'13'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_12_003'
      ,'SSSHBG_20251203_1_0605_1_12'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_12_004'
      ,'SSSHBG_20251203_1_0605_1_12'
      ,'Live'
      ,'22'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_12_005'
      ,'SSSHBG_20251203_1_0605_1_12'
      ,'Live'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_12_006'
      ,'SSSHBG_20251203_1_0605_1_12'
      ,'Live'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_001'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_002'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_003'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_004'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_005'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_006'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'6'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_007'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_008'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_009'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_010'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_011'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_012'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_013'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_014'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_015'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'2'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_016'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'9'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_017'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_018'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_019'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'9'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_020'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_021'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'9'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_022'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_023'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'6'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_024'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_025'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'6'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_026'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_027'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_028'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_029'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_030'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_031'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_032'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_033'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_034'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_035'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_036'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_037'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_038'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_039'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_040'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_041'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_042'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_043'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_044'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_045'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_046'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_047'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_048'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'6'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_049'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_050'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_051'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Dead'
      ,'13'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_052'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Dead'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_053'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Dead'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_054'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Dead'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_055'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Dead'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_056'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Dead'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_057'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Dead'
      ,'6'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_14_058'
      ,'SSSHBG_20251203_1_0605_1_14'
      ,'Dead'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_001'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_002'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_003'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'6'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_004'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'6'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_005'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_006'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_007'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_008'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'2'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_009'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_010'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_011'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_012'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_013'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_014'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_015'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_016'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_017'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'6'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_018'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_019'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_020'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_021'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_022'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'6'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_023'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_024'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_025'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_026'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_027'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_028'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_029'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_030'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'2'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_031'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_032'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_033'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'9'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_034'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'6'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_035'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'6'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_036'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_037'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_038'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_039'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_040'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_041'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_042'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'9'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_043'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_044'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'6'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_045'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_046'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_047'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_048'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_049'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0605_1_15_050'
      ,'SSSHBG_20251203_1_0605_1_15'
      ,'Live'
      ,'6'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_02_001'
      ,'SSSHBG_20251203_1_0606_1_02'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_02_002'
      ,'SSSHBG_20251203_1_0606_1_02'
      ,'Live'
      ,'9'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_02_003'
      ,'SSSHBG_20251203_1_0606_1_02'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_02_004'
      ,'SSSHBG_20251203_1_0606_1_02'
      ,'Live'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_02_005'
      ,'SSSHBG_20251203_1_0606_1_02'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_02_006'
      ,'SSSHBG_20251203_1_0606_1_02'
      ,'Live'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_03_001'
      ,'SSSHBG_20251203_1_0606_1_03'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_03_002'
      ,'SSSHBG_20251203_1_0606_1_03'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_03_003'
      ,'SSSHBG_20251203_1_0606_1_03'
      ,'Live'
      ,'6'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_03_004'
      ,'SSSHBG_20251203_1_0606_1_03'
      ,'Live'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_04_001'
      ,'SSSHBG_20251203_1_0606_1_04'
      ,'Live'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_06_001'
      ,'SSSHBG_20251203_1_0606_1_06'
      ,'Live'
      ,'1'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_07_001'
      ,'SSSHBG_20251203_1_0606_1_07'
      ,'Live'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_07_002'
      ,'SSSHBG_20251203_1_0606_1_07'
      ,'Live'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_07_003'
      ,'SSSHBG_20251203_1_0606_1_07'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_07_004'
      ,'SSSHBG_20251203_1_0606_1_07'
      ,'Live'
      ,'13'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_07_005'
      ,'SSSHBG_20251203_1_0606_1_07'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_07_006'
      ,'SSSHBG_20251203_1_0606_1_07'
      ,'Live'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_08_001'
      ,'SSSHBG_20251203_1_0606_1_08'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_08_002'
      ,'SSSHBG_20251203_1_0606_1_08'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_08_003'
      ,'SSSHBG_20251203_1_0606_1_08'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_09_001'
      ,'SSSHBG_20251203_1_0606_1_09'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_10_001'
      ,'SSSHBG_20251203_1_0606_1_10'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_11_001'
      ,'SSSHBG_20251203_1_0606_1_11'
      ,'Live'
      ,'9'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_11_002'
      ,'SSSHBG_20251203_1_0606_1_11'
      ,'Dead'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_12_001'
      ,'SSSHBG_20251203_1_0606_1_12'
      ,'Live'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_12_002'
      ,'SSSHBG_20251203_1_0606_1_12'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_12_003'
      ,'SSSHBG_20251203_1_0606_1_12'
      ,'Live'
      ,'2'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_12_004'
      ,'SSSHBG_20251203_1_0606_1_12'
      ,'Live'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_12_005'
      ,'SSSHBG_20251203_1_0606_1_12'
      ,'Live'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_12_006'
      ,'SSSHBG_20251203_1_0606_1_12'
      ,'Live'
      ,'17'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_12_007'
      ,'SSSHBG_20251203_1_0606_1_12'
      ,'Live'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_12_008'
      ,'SSSHBG_20251203_1_0606_1_12'
      ,'Live'
      ,'14'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_12_009'
      ,'SSSHBG_20251203_1_0606_1_12'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_12_010'
      ,'SSSHBG_20251203_1_0606_1_12'
      ,'Live'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_001'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_002'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_003'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_004'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_005'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'13'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_006'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_007'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'6'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_008'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_009'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_010'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_011'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_012'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'20'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_013'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'19'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_014'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'6'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_015'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_016'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_017'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_018'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_019'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_020'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'13'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_021'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_022'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'12'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_023'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_024'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_025'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'13'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_026'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'14'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_027'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_028'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_029'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_030'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'9'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_031'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_032'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_033'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'9'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_034'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_035'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_036'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'3'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_037'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'6'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_038'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'13'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_039'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'6'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_040'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'9'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_041'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_042'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_043'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_044'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_045'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_046'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'6'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_047'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'6'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_048'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_049'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'13'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_050'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Live'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_051'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Dead'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_052'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Dead'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_053'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Dead'
      ,'14'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_054'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Dead'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_055'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Dead'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_056'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Dead'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_057'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Dead'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_058'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Dead'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_059'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Dead'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_060'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Dead'
      ,'15'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_061'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Dead'
      ,'14'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_062'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Dead'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_063'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Dead'
      ,'11'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_064'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Dead'
      ,'8'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_065'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Dead'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_066'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Dead'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_067'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Dead'
      ,'13'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_13_068'
      ,'SSSHBG_20251203_1_0606_1_13'
      ,'Dead'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_14_001'
      ,'SSSHBG_20251203_1_0606_1_14'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_14_002'
      ,'SSSHBG_20251203_1_0606_1_14'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_14_003'
      ,'SSSHBG_20251203_1_0606_1_14'
      ,'Live'
      ,'13'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_14_004'
      ,'SSSHBG_20251203_1_0606_1_14'
      ,'Live'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_14_005'
      ,'SSSHBG_20251203_1_0606_1_14'
      ,'Live'
      ,'9'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_14_006'
      ,'SSSHBG_20251203_1_0606_1_14'
      ,'Live'
      ,'5'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_14_007'
      ,'SSSHBG_20251203_1_0606_1_14'
      ,'Live'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_15_001'
      ,'SSSHBG_20251203_1_0606_1_15'
      ,'Dead'
      ,'13'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_15_002'
      ,'SSSHBG_20251203_1_0606_1_15'
      ,'Dead'
      ,'4'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO


    INSERT INTO [dbo].[ShellBudgetSH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[LiveOrDead]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSHBG_20251203_1_0606_1_15_003'
      ,'SSSHBG_20251203_1_0606_1_15'
      ,'Dead'
      ,'7'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'NumDead = 0  Total Dead = 0')
 GO
