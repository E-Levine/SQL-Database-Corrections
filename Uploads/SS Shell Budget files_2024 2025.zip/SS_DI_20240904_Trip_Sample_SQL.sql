
INSERT INTO [dbo].[TripInfo]
           ([TripID]
           ,[TripType]
           ,[TripDate]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy])
     VALUES
      ('SSSHBG_20240904_1'
      ,'Shell Budget'
      ,'2024-09-04'
      ,'Proofed'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze')
 GO


INSERT INTO [dbo].[SampleEvent]
           ([SampleEventID]
           ,[TripID]
           ,[FixedLocationID]
           ,[LatitudeDec]
           ,[LongitudeDec]
           ,[NumDrills]
           ,[HarvestStatus]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy])
     VALUES
      ('SSSHBG_20240904_1_0615_1'
      ,'SSSHBG_20240904_1'
      ,'0615'
      ,'29.23852'
      ,'-83.07738'
      ,NULL
      ,'Conditionally Approved'
      ,'Proofed'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze')
 GO


INSERT INTO [dbo].[SampleEvent]
           ([SampleEventID]
           ,[TripID]
           ,[FixedLocationID]
           ,[LatitudeDec]
           ,[LongitudeDec]
           ,[NumDrills]
           ,[HarvestStatus]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy])
     VALUES
      ('SSSHBG_20240904_1_0616_1'
      ,'SSSHBG_20240904_1'
      ,'0616'
      ,'29.23419'
      ,'-83.07166'
      ,NULL
      ,'Prohibited'
      ,'Proofed'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze')
 GO


INSERT INTO [dbo].[SampleEvent]
           ([SampleEventID]
           ,[TripID]
           ,[FixedLocationID]
           ,[LatitudeDec]
           ,[LongitudeDec]
           ,[NumDrills]
           ,[HarvestStatus]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy])
     VALUES
      ('SSSHBG_20240904_1_0617_1'
      ,'SSSHBG_20240904_1'
      ,'0617'
      ,'29.23091'
      ,'-83.07697'
      ,NULL
      ,'Conditionally Approved'
      ,'Proofed'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze')
 GO


INSERT INTO [dbo].[SampleEvent]
           ([SampleEventID]
           ,[TripID]
           ,[FixedLocationID]
           ,[LatitudeDec]
           ,[LongitudeDec]
           ,[NumDrills]
           ,[HarvestStatus]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy])
     VALUES
      ('SSSHBG_20240904_1_0618_1'
      ,'SSSHBG_20240904_1'
      ,'0618'
      ,'29.23559'
      ,'-83.07294'
      ,NULL
      ,'Prohibited'
      ,'Proofed'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze')
 GO


INSERT INTO [dbo].[SampleEventWQ]
           ([SampleEventWQID]
           ,[SampleEventID]
           ,[Temperature]
           ,[Salinity]
           ,[DissolvedOxygen]
           ,[pH]
           ,[Depth]
           ,[TurbidityYSI]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments]
           ,[CollectionTime])
     VALUES
      ('SSSHBG_20240904_1_0615_1_01'
      ,'SSSHBG_20240904_1_0615_1'
      ,'28'
      ,'19.89'
      ,'4.94'
      ,'7.4'
      ,'0.25'
      ,'16.82'
      ,'Proofed'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze'
      ,'DPTH_STRTA = I BOTTOM_TYP = OY'
      ,'0956')
 GO


INSERT INTO [dbo].[SampleEventWQ]
           ([SampleEventWQID]
           ,[SampleEventID]
           ,[Temperature]
           ,[Salinity]
           ,[DissolvedOxygen]
           ,[pH]
           ,[Depth]
           ,[TurbidityYSI]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments]
           ,[CollectionTime])
     VALUES
      ('SSSHBG_20240904_1_0616_1_01'
      ,'SSSHBG_20240904_1_0616_1'
      ,'28.9'
      ,'21.1'
      ,'5.88'
      ,'7.47'
      ,'0.25'
      ,'18.94'
      ,'Proofed'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze'
      ,'DPTH_STRTA = I BOTTOM_TYP = OY'
      ,'1145')
 GO


INSERT INTO [dbo].[SampleEventWQ]
           ([SampleEventWQID]
           ,[SampleEventID]
           ,[Temperature]
           ,[Salinity]
           ,[DissolvedOxygen]
           ,[pH]
           ,[Depth]
           ,[TurbidityYSI]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments]
           ,[CollectionTime])
     VALUES
      ('SSSHBG_20240904_1_0617_1_01'
      ,'SSSHBG_20240904_1_0617_1'
      ,'29.2'
      ,'21.79'
      ,'6.35'
      ,'7.61'
      ,'0.5'
      ,'6.5'
      ,'Proofed'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze'
      ,'DPTH_STRTA = I BOTTOM_TYP = HA'
      ,'1245')
 GO


INSERT INTO [dbo].[SampleEventWQ]
           ([SampleEventWQID]
           ,[SampleEventID]
           ,[Temperature]
           ,[Salinity]
           ,[DissolvedOxygen]
           ,[pH]
           ,[Depth]
           ,[TurbidityYSI]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments]
           ,[CollectionTime])
     VALUES
      ('SSSHBG_20240904_1_0618_1_01'
      ,'SSSHBG_20240904_1_0618_1'
      ,'28.4'
      ,'20.32'
      ,'5.5'
      ,'7.44'
      ,'0.25'
      ,'5.52'
      ,'Proofed'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze'
      ,'DPTH_STRTA = I BOTTOM_TYP = HA'
      ,'1055')
 GO
