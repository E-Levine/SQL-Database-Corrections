
INSERT INTO [dbo].[TripInfo]
           ([TripID]
           ,[TripType]
           ,[TripDate]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy])
     VALUES
      ('SSSHBG_20250127_1'
      ,'Shell Budget'
      ,'2025-01-27'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze')
 GO


INSERT INTO [dbo].[SampleEvent]
           ([SampleEventID]
           ,[TripID]
           ,[FixedLocationID]
           ,[LatitudeDec]
           ,[LongitudeDec]
           ,[NumDrills]
           ,[HarvestStatus]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy])
     VALUES
      ('SSSHBG_20250127_1_0613_1'
      ,'SSSHBG_20250127_1'
      ,'0613'
      ,'29.23869'
      ,'-83.07112'
      ,NULL
      ,'Conditionally Approved'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze')
 GO


INSERT INTO [dbo].[SampleEvent]
           ([SampleEventID]
           ,[TripID]
           ,[FixedLocationID]
           ,[LatitudeDec]
           ,[LongitudeDec]
           ,[NumDrills]
           ,[HarvestStatus]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy])
     VALUES
      ('SSSHBG_20250127_1_0615_1'
      ,'SSSHBG_20250127_1'
      ,'0615'
      ,'0'
      ,'0'
      ,NULL
      ,'Conditionally Approved'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze')
 GO


INSERT INTO [dbo].[SampleEvent]
           ([SampleEventID]
           ,[TripID]
           ,[FixedLocationID]
           ,[LatitudeDec]
           ,[LongitudeDec]
           ,[NumDrills]
           ,[HarvestStatus]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy])
     VALUES
      ('SSSHBG_20250127_1_0616_1'
      ,'SSSHBG_20250127_1'
      ,'0616'
      ,'29.23394'
      ,'-83.07161'
      ,NULL
      ,'Conditionally Approved'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze')
 GO


INSERT INTO [dbo].[SampleEvent]
           ([SampleEventID]
           ,[TripID]
           ,[FixedLocationID]
           ,[LatitudeDec]
           ,[LongitudeDec]
           ,[NumDrills]
           ,[HarvestStatus]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy])
     VALUES
      ('SSSHBG_20250127_1_0618_1'
      ,'SSSHBG_20250127_1'
      ,'0618'
      ,'29.23591'
      ,'-83.07262'
      ,NULL
      ,'Conditionally Approved'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze')
 GO


INSERT INTO [dbo].[SampleEventWQ]
           ([SampleEventWQID]
           ,[SampleEventID]
           ,[Temperature]
           ,[Salinity]
           ,[DissolvedOxygen]
           ,[pH]
           ,[Depth]
           ,[TurbidityYSI]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments]
           ,[CollectionTime])
     VALUES
      ('SSSHBG_20250127_1_0613_1_01'
      ,'SSSHBG_20250127_1_0613_1'
      ,'12.8'
      ,'21.89'
      ,'11.76'
      ,'7.97'
      ,'0.25'
      ,'10'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL
      ,'1103')
 GO


INSERT INTO [dbo].[SampleEventWQ]
           ([SampleEventWQID]
           ,[SampleEventID]
           ,[Temperature]
           ,[Salinity]
           ,[DissolvedOxygen]
           ,[pH]
           ,[Depth]
           ,[TurbidityYSI]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments]
           ,[CollectionTime])
     VALUES
      ('SSSHBG_20250127_1_0615_1_01'
      ,'SSSHBG_20250127_1_0615_1'
      ,'11.5'
      ,'25.25'
      ,'11.47'
      ,'8'
      ,'0.5'
      ,'4.22'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL
      ,'1235')
 GO


INSERT INTO [dbo].[SampleEventWQ]
           ([SampleEventWQID]
           ,[SampleEventID]
           ,[Temperature]
           ,[Salinity]
           ,[DissolvedOxygen]
           ,[pH]
           ,[Depth]
           ,[TurbidityYSI]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments]
           ,[CollectionTime])
     VALUES
      ('SSSHBG_20250127_1_0616_1_01'
      ,'SSSHBG_20250127_1_0616_1'
      ,'13.6'
      ,'24.56'
      ,'11.7'
      ,'8.08'
      ,'0.5'
      ,'10.56'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL
      ,'1407')
 GO


INSERT INTO [dbo].[SampleEventWQ]
           ([SampleEventWQID]
           ,[SampleEventID]
           ,[Temperature]
           ,[Salinity]
           ,[DissolvedOxygen]
           ,[pH]
           ,[Depth]
           ,[TurbidityYSI]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments]
           ,[CollectionTime])
     VALUES
      ('SSSHBG_20250127_1_0618_1_01'
      ,'SSSHBG_20250127_1_0618_1'
      ,'12.3'
      ,'24.24'
      ,'12.08'
      ,'8.07'
      ,'0.5'
      ,'5.43'
      ,'Proofed'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-11 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL
      ,'1325')
 GO
