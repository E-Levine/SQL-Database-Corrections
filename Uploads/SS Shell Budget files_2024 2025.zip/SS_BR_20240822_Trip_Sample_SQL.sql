
INSERT INTO [dbo].[TripInfo]
           ([TripID]
           ,[TripType]
           ,[TripDate]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy])
     VALUES
      ('SSSHBG_20240822_1'
      ,'Shell Budget'
      ,'2024-08-22'
      ,'Proofed'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze')
 GO


INSERT INTO [dbo].[SampleEvent]
           ([SampleEventID]
           ,[TripID]
           ,[FixedLocationID]
           ,[LatitudeDec]
           ,[LongitudeDec]
           ,[NumDrills]
           ,[HarvestStatus]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy])
     VALUES
      ('SSSHBG_20240822_1_0601_1'
      ,'SSSHBG_20240822_1'
      ,'0601'
      ,'29.22741'
      ,'-83.13421'
      ,NULL
      ,'Approved'
      ,'Proofed'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze')
 GO


INSERT INTO [dbo].[SampleEvent]
           ([SampleEventID]
           ,[TripID]
           ,[FixedLocationID]
           ,[LatitudeDec]
           ,[LongitudeDec]
           ,[NumDrills]
           ,[HarvestStatus]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy])
     VALUES
      ('SSSHBG_20240822_1_0602_1'
      ,'SSSHBG_20240822_1'
      ,'0602'
      ,'29.22923'
      ,'-83.13617'
      ,NULL
      ,'Approved'
      ,'Proofed'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze')
 GO


INSERT INTO [dbo].[SampleEvent]
           ([SampleEventID]
           ,[TripID]
           ,[FixedLocationID]
           ,[LatitudeDec]
           ,[LongitudeDec]
           ,[NumDrills]
           ,[HarvestStatus]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy])
     VALUES
      ('SSSHBG_20240822_1_0606_1'
      ,'SSSHBG_20240822_1'
      ,'0606'
      ,'29.23085'
      ,'-83.13746'
      ,NULL
      ,'Approved'
      ,'Proofed'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze')
 GO


INSERT INTO [dbo].[SampleEventWQ]
           ([SampleEventWQID]
           ,[SampleEventID]
           ,[Temperature]
           ,[Salinity]
           ,[DissolvedOxygen]
           ,[pH]
           ,[Depth]
           ,[TurbidityYSI]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments]
           ,[CollectionTime])
     VALUES
      ('SSSHBG_20240822_1_0601_1_01'
      ,'SSSHBG_20240822_1_0601_1'
      ,'30.2'
      ,'8.95'
      ,'2.78'
      ,'7.1'
      ,'1.5'
      ,'4.4'
      ,'Proofed'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze'
      ,'DPTH_STRTA = S BOTTOM_TYP = SA'
      ,'1042')
 GO


INSERT INTO [dbo].[SampleEventWQ]
           ([SampleEventWQID]
           ,[SampleEventID]
           ,[Temperature]
           ,[Salinity]
           ,[DissolvedOxygen]
           ,[pH]
           ,[Depth]
           ,[TurbidityYSI]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments]
           ,[CollectionTime])
     VALUES
      ('SSSHBG_20240822_1_0602_1_01'
      ,'SSSHBG_20240822_1_0602_1'
      ,'30.3'
      ,'7.64'
      ,'3.7'
      ,'7.12'
      ,'1.5'
      ,'2.83'
      ,'Proofed'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze'
      ,'DPTH_STRTA = S BOTTOM_TYP = HA'
      ,'1139')
 GO


INSERT INTO [dbo].[SampleEventWQ]
           ([SampleEventWQID]
           ,[SampleEventID]
           ,[Temperature]
           ,[Salinity]
           ,[DissolvedOxygen]
           ,[pH]
           ,[Depth]
           ,[TurbidityYSI]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments]
           ,[CollectionTime])
     VALUES
      ('SSSHBG_20240822_1_0606_1_01'
      ,'SSSHBG_20240822_1_0606_1'
      ,'31.1'
      ,'19.07'
      ,'4.21'
      ,'7.45'
      ,'1.75'
      ,'5.33'
      ,'Proofed'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-08-06 00:00:00.000'
      ,'Tomena Scholze'
      ,'DPTH_STRTA = S BOTTOM_TYP = SA'
      ,'1230')
 GO
