
INSERT INTO [dbo].[FixedLocations]
           ([FixedLocationID]
           ,[Estuary]
           ,[SectionName]
           ,[StationName]
           ,[StationNumber]
           ,[LatitudeDec]
           ,[LongitudeDec]
           ,[Recruitment]
           ,[Survey]
           ,[Sediment]
           ,[Collections]
           ,[ShellBudget]
           ,[Dataloggers]
           ,[Cage]
           ,[Wave]
           ,[StartDate]
           ,[EndDate]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments]
           ,[AdminNotes]
           ,[StationNameNumber]
           ,[EstuaryLongName])
VALUES
      ('I150'
      ,'WC'
      ,'C'
      ,'WIO13'
      ,'13'
      ,'29.0275'
      ,'-82.81083'
      ,'N'
      ,'Y'
      ,'N'
      ,'N'
      ,'N'
      ,'N'
      ,'N'
      ,'N'
      ,'2026-03-04'
      ,'2026-03-04'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'SAND'
      ,'datalogger upload FixedLocationID'
      ,'WIO13-O13'
      ,'Withlacoochee/Crystal River')
 GO


INSERT INTO [dbo].[SampleEvent]
           ([SampleEventID]
           ,[TripID]
           ,[FixedLocationID]
           ,[LatitudeDec]
           ,[LongitudeDec]
           ,[HarvestStatus]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy])
     VALUES
      ('WCSRVY_20260304_1_I150_1'
      ,'WCSRVY_20260304_1'
      ,'I150'
      ,'29.0275'
      ,'-82.81083'
      ,'Conditionally Approved'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze')
 GO


INSERT INTO [dbo].[SampleEventWQ]
           ([SampleEventWQID]
           ,[SampleEventID]
           ,[Temperature]
           ,[Salinity]
           ,[DissolvedOxygen]
           ,[pH]
           ,[Depth]
           ,[TurbidityYSI]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments]
           ,[CollectionTime])
     VALUES
      ('WCSRVY_20260304_1_I150_1_01'
      ,'WCSRVY_20260304_1_I150_1'
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,NULL
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'Notes = SAND DPTH_STRTA = S BOTTOM_TYP = SA'
      ,'1710')
 GO
