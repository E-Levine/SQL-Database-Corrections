
INSERT INTO [dbo].[FixedLocations]
           ([FixedLocationID]
           ,[Estuary]
           ,[SectionName]
           ,[StationName]
           ,[StationNumber]
           ,[LatitudeDec]
           ,[LongitudeDec]
           ,[Recruitment]
           ,[Survey]
           ,[Sediment]
           ,[Collections]
           ,[ShellBudget]
           ,[Dataloggers]
           ,[Cage]
           ,[Wave]
           ,[StartDate]
           ,[EndDate]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments]
           ,[AdminNotes]
           ,[StationNameNumber]
           ,[EstuaryLongName])
VALUES
      ('I118'
      ,'WC'
      ,'C'
      ,'WIO26'
      ,'26'
      ,'29.04027'
      ,'-82.80486'
      ,'N'
      ,'Y'
      ,'N'
      ,'N'
      ,'N'
      ,'N'
      ,'N'
      ,'N'
      ,'2026-03-04'
      ,'2026-03-04'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'LIME'
      ,'datalogger upload FixedLocationID'
      ,'WIO26-O26'
      ,'Withlacoochee/Crystal River')
 GO


INSERT INTO [dbo].[TripInfo]
           ([TripID]
           ,[TripType]
           ,[TripDate]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy])
     VALUES
      ('WCSRVY_20260304_1'
      ,'Survey'
      ,'2026-03-04'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze')
 GO


INSERT INTO [dbo].[SampleEvent]
           ([SampleEventID]
           ,[TripID]
           ,[FixedLocationID]
           ,[LatitudeDec]
           ,[LongitudeDec]
           ,[HarvestStatus]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy])
     VALUES
      ('WCSRVY_20260304_1_I118_1'
      ,'WCSRVY_20260304_1'
      ,'I118'
      ,'29.04027'
      ,'-82.80486'
      ,'Conditionally Approved'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze')
 GO


INSERT INTO [dbo].[SampleEventWQ]
           ([SampleEventWQID]
           ,[SampleEventID]
           ,[Temperature]
           ,[Salinity]
           ,[DissolvedOxygen]
           ,[pH]
           ,[Depth]
           ,[TurbidityYSI]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments]
           ,[CollectionTime])
     VALUES
      ('WCSRVY_20260304_1_I118_1_01'
      ,'WCSRVY_20260304_1_I118_1'
      ,'20.2'
      ,'26.76'
      ,'7.52'
      ,'7.82'
      ,'0.25'
      ,'0.35'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'Notes = LIME DPTH_STRTA = I BOTTOM_TYP = OY'
      ,'0939')
 GO
