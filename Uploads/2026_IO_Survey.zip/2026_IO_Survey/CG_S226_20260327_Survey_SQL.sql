
INSERT INTO [dbo].[SurveyQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[NumLive]
           ,[NumDead]
           ,[TotalVolume]
           ,[TotalWeight]
           ,[NumDrills]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments]
           ,[NumLegal])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01'
      ,'SSSRVY_20260327_1_S226_1'
      ,'1'
      ,'199'
      ,'22'
      ,'0'
      ,'4.02'
      ,'0'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0'
      ,'0')
 GO


INSERT INTO [dbo].[SurveyQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[NumLive]
           ,[NumDead]
           ,[TotalVolume]
           ,[TotalWeight]
           ,[NumDrills]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments]
           ,[NumLegal])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02'
      ,'SSSRVY_20260327_1_S226_1'
      ,'2'
      ,'234'
      ,'39'
      ,'0'
      ,'5.09'
      ,'0'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0'
      ,'0')
 GO


INSERT INTO [dbo].[SurveyQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[NumLive]
           ,[NumDead]
           ,[TotalVolume]
           ,[TotalWeight]
           ,[NumDrills]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments]
           ,[NumLegal])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03'
      ,'SSSRVY_20260327_1_S226_1'
      ,'3'
      ,'213'
      ,'60'
      ,'0'
      ,'5.65'
      ,'0'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0'
      ,'0')
 GO


INSERT INTO [dbo].[SurveyQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[NumLive]
           ,[NumDead]
           ,[TotalVolume]
           ,[TotalWeight]
           ,[NumDrills]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments]
           ,[NumLegal])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04'
      ,'SSSRVY_20260327_1_S226_1'
      ,'4'
      ,'586'
      ,'95'
      ,'0'
      ,'16.88'
      ,'0'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0'
      ,'0')
 GO


INSERT INTO [dbo].[SurveyQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[NumLive]
           ,[NumDead]
           ,[TotalVolume]
           ,[TotalWeight]
           ,[NumDrills]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments]
           ,[NumLegal])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05'
      ,'SSSRVY_20260327_1_S226_1'
      ,'5'
      ,'365'
      ,'64'
      ,'0'
      ,'8.36'
      ,'0'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 1'
      ,'0')
 GO


INSERT INTO [dbo].[SurveyQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[NumLive]
           ,[NumDead]
           ,[TotalVolume]
           ,[TotalWeight]
           ,[NumDrills]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments]
           ,[NumLegal])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06'
      ,'SSSRVY_20260327_1_S226_1'
      ,'6'
      ,'344'
      ,'80'
      ,'0'
      ,'10.94'
      ,'0'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0'
      ,'0')
 GO


INSERT INTO [dbo].[SurveyQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[NumLive]
           ,[NumDead]
           ,[TotalVolume]
           ,[TotalWeight]
           ,[NumDrills]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments]
           ,[NumLegal])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07'
      ,'SSSRVY_20260327_1_S226_1'
      ,'7'
      ,'339'
      ,'68'
      ,'0'
      ,'10.5'
      ,'0'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0'
      ,'0')
 GO


INSERT INTO [dbo].[SurveyQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[NumLive]
           ,[NumDead]
           ,[TotalVolume]
           ,[TotalWeight]
           ,[NumDrills]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments]
           ,[NumLegal])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08'
      ,'SSSRVY_20260327_1_S226_1'
      ,'8'
      ,'421'
      ,'130'
      ,'0'
      ,'13.05'
      ,'0'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 1'
      ,'3')
 GO


INSERT INTO [dbo].[SurveyQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[NumLive]
           ,[NumDead]
           ,[TotalVolume]
           ,[TotalWeight]
           ,[NumDrills]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments]
           ,[NumLegal])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09'
      ,'SSSRVY_20260327_1_S226_1'
      ,'9'
      ,'158'
      ,'45'
      ,'0'
      ,'2.26'
      ,'0'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0'
      ,'0')
 GO


INSERT INTO [dbo].[SurveyQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[NumLive]
           ,[NumDead]
           ,[TotalVolume]
           ,[TotalWeight]
           ,[NumDrills]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments]
           ,[NumLegal])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10'
      ,'SSSRVY_20260327_1_S226_1'
      ,'10'
      ,'70'
      ,'27'
      ,'0'
      ,'1.35'
      ,'0'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0'
      ,'0')
 GO


INSERT INTO [dbo].[SurveyQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[NumLive]
           ,[NumDead]
           ,[TotalVolume]
           ,[TotalWeight]
           ,[NumDrills]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments]
           ,[NumLegal])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11'
      ,'SSSRVY_20260327_1_S226_1'
      ,'11'
      ,'156'
      ,'47'
      ,'0'
      ,'2.68'
      ,'0'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0'
      ,'1')
 GO


INSERT INTO [dbo].[SurveyQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[NumLive]
           ,[NumDead]
           ,[TotalVolume]
           ,[TotalWeight]
           ,[NumDrills]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments]
           ,[NumLegal])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12'
      ,'SSSRVY_20260327_1_S226_1'
      ,'12'
      ,'52'
      ,'28'
      ,'0'
      ,'1.54'
      ,'0'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0'
      ,'0')
 GO


INSERT INTO [dbo].[SurveyQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[NumLive]
           ,[NumDead]
           ,[TotalVolume]
           ,[TotalWeight]
           ,[NumDrills]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments]
           ,[NumLegal])
     VALUES
      ('SSSRVY_20260327_1_S226_1_13'
      ,'SSSRVY_20260327_1_S226_1'
      ,'13'
      ,'23'
      ,'18'
      ,'0'
      ,'0.76'
      ,'1'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 1'
      ,'0')
 GO


INSERT INTO [dbo].[SurveyQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[NumLive]
           ,[NumDead]
           ,[TotalVolume]
           ,[TotalWeight]
           ,[NumDrills]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments]
           ,[NumLegal])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14'
      ,'SSSRVY_20260327_1_S226_1'
      ,'14'
      ,'84'
      ,'33'
      ,'0'
      ,'1.4'
      ,'0'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 2'
      ,'0')
 GO


INSERT INTO [dbo].[SurveyQuadrat]
           ([QuadratID]
           ,[SampleEventID]
           ,[QuadratNumber]
           ,[NumLive]
           ,[NumDead]
           ,[TotalVolume]
           ,[TotalWeight]
           ,[NumDrills]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments]
           ,[NumLegal])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15'
      ,'SSSRVY_20260327_1_S226_1'
      ,'15'
      ,'119'
      ,'23'
      ,'0'
      ,'1.97'
      ,'0'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'Conch = 0'
      ,'0')
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_001'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_002'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_003'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'13'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_004'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'42'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_005'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'21'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_006'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'31'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_007'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'37'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_008'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'36'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_009'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'38'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_010'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'15'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_011'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'34'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_012'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'52'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_013'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'35'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_014'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_015'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'36'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_016'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'40'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_017'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'66'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_018'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'35'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_019'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'27'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_020'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'26'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_021'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'15'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_022'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'28'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_023'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'43'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_024'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_025'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_026'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'31'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_027'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'22'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_028'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'36'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_029'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'40'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_030'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'18'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_031'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'15'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_032'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'22'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_033'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'21'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_034'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'22'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_035'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'23'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_036'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_037'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'22'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_038'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'27'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_039'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'15'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_040'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_041'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'11'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_042'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'35'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_043'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'25'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_044'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'26'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_045'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_046'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'38'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_047'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'26'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_048'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'15'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_049'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'10'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_01_050'
      ,'SSSRVY_20260327_1_S226_1_01'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_001'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_002'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'22'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_003'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'26'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_004'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'24'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_005'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'31'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_006'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'36'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_007'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'32'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_008'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'36'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_009'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'49'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_010'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'38'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_011'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'12'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_012'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_013'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'40'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_014'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'31'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_015'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_016'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'25'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_017'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'38'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_018'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'28'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_019'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'22'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_020'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'35'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_021'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'36'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_022'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'15'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_023'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'29'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_024'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'28'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_025'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'16'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_026'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'35'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_027'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_028'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_029'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'15'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_030'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'35'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_031'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'21'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_032'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'17'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_033'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'31'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_034'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'39'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_035'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'38'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_036'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'36'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_037'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'28'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_038'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_039'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_040'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'29'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_041'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'19'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_042'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'22'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_043'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'16'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_044'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'29'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_045'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'15'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_046'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'31'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_047'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'40'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_048'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'21'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_049'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'15'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_02_050'
      ,'SSSRVY_20260327_1_S226_1_02'
      ,'15'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_001'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'42'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_002'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'45'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_003'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_004'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_005'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'15'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_006'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'27'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_007'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'33'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_008'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'36'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_009'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_010'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_011'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'22'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_012'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'18'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_013'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'31'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_014'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'41'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_015'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'35'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_016'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'52'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_017'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'47'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_018'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'36'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_019'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'35'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_020'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'34'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_021'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'27'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_022'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'22'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_023'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'32'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_024'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'35'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_025'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'13'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_026'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'15'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_027'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'21'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_028'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'22'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_029'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'31'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_030'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'33'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_031'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'22'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_032'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'23'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_033'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_034'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'21'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_035'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_036'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'35'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_037'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'28'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_038'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'28'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_039'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'41'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_040'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_041'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_042'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'26'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_043'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'36'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_044'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'40'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_045'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'28'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_046'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'41'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_047'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_048'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'50'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_049'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'35'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_03_050'
      ,'SSSRVY_20260327_1_S226_1_03'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_001'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_002'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'15'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_003'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_004'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'14'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_005'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'51'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_006'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_007'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'31'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_008'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'25'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_009'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'26'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_010'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'27'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_011'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'26'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_012'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_013'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'23'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_014'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'23'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_015'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'31'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_016'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'15'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_017'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'17'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_018'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'18'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_019'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'11'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_020'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_021'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'29'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_022'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'31'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_023'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'14'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_024'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'42'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_025'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'11'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_026'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'26'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_027'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'37'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_028'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'21'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_029'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'52'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_030'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'25'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_031'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'26'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_032'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'26'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_033'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'31'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_034'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'49'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_035'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'34'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_036'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'47'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_037'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'21'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_038'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'25'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_039'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'46'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_040'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'37'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_041'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'41'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_042'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_043'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'15'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_044'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'17'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_045'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'26'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_046'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'25'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_047'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'32'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_048'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_049'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'45'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_04_050'
      ,'SSSRVY_20260327_1_S226_1_04'
      ,'12'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_001'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'31'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_002'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_003'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'10'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_004'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'11'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_005'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'31'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_006'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'14'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_007'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_008'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'36'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_009'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'35'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_010'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'52'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_011'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_012'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'47'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_013'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'40'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_014'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'14'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_015'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_016'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'32'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_017'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'31'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_018'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'24'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_019'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'36'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_020'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'10'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_021'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_022'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'50'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_023'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'44'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_024'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'35'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_025'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'15'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_026'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'10'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_027'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'40'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_028'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'32'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_029'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'34'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_030'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'23'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_031'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'25'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_032'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'31'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_033'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'43'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_034'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'42'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_035'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'40'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_036'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'38'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_037'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'15'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_038'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'41'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_039'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'10'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_040'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'10'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_041'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'46'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_042'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'51'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_043'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'42'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_044'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'40'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_045'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_046'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'40'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_047'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'51'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_048'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'31'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_049'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'28'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_05_050'
      ,'SSSRVY_20260327_1_S226_1_05'
      ,'37'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_001'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'31'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_002'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_003'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'22'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_004'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_005'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'33'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_006'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_007'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_008'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'25'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_009'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'15'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_010'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'31'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_011'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'26'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_012'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'27'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_013'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'15'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_014'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'18'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_015'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'31'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_016'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'27'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_017'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'15'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_018'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'33'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_019'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'46'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_020'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'22'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_021'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'25'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_022'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'41'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_023'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'32'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_024'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'36'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_025'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'29'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_026'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'38'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_027'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'34'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_028'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'27'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_029'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'15'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_030'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'31'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_031'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'26'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_032'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'21'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_033'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'27'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_034'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'27'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_035'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'27'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_036'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'35'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_037'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_038'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'50'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_039'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_040'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'45'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_041'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_042'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'36'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_043'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'32'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_044'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'26'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_045'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'38'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_046'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'40'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_047'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_048'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'31'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_049'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'35'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_06_050'
      ,'SSSRVY_20260327_1_S226_1_06'
      ,'41'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_001'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_002'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_003'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'32'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_004'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'61'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_005'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'41'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_006'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'36'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_007'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'15'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_008'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_009'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_010'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'42'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_011'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'21'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_012'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'40'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_013'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_014'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'24'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_015'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_016'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'25'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_017'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_018'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'13'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_019'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'15'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_020'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'31'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_021'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'32'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_022'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'37'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_023'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'21'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_024'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_025'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'26'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_026'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'10'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_027'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'31'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_028'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_029'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'19'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_030'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_031'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'31'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_032'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'40'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_033'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'42'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_034'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'27'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_035'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'31'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_036'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'27'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_037'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'46'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_038'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'43'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_039'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'33'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_040'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'21'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_041'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'25'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_042'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'32'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_043'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'36'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_044'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'37'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_045'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'15'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_046'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_047'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'24'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_048'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'40'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_049'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'46'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_07_050'
      ,'SSSRVY_20260327_1_S226_1_07'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_001'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'22'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_002'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'42'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_003'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'36'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_004'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'31'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_005'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'35'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_006'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'26'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_007'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'24'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_008'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_009'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'11'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_010'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'15'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_011'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'17'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_012'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_013'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'18'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_014'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'45'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_015'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'35'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_016'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'40'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_017'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'54'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_018'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'24'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_019'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'15'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_020'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'18'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_021'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'46'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_022'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'27'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_023'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'15'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_024'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'13'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_025'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'11'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_026'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'18'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_027'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'15'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_028'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'26'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_029'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_030'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'10'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_031'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'16'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_032'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'51'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_033'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'42'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_034'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'31'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_035'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'32'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_036'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'32'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_037'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'21'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_038'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'54'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_039'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'36'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_040'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'25'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_041'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'37'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_042'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'24'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_043'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'35'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_044'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'40'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_045'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'27'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_046'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'21'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_047'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'32'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_048'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'22'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_049'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'13'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_08_050'
      ,'SSSRVY_20260327_1_S226_1_08'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_001'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'45'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_002'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'24'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_003'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'25'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_004'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'21'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_005'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'40'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_006'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'32'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_007'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'28'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_008'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'33'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_009'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'50'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_010'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'31'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_011'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_012'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'22'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_013'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'25'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_014'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'29'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_015'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'36'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_016'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'10'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_017'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'41'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_018'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'45'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_019'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'31'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_020'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'56'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_021'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'23'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_022'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'22'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_023'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_024'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'41'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_025'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'47'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_026'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'47'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_027'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'44'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_028'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'19'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_029'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'22'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_030'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'31'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_031'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'22'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_032'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'44'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_033'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'29'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_034'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'40'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_035'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'45'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_036'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'21'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_037'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'41'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_038'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_039'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'39'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_040'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'43'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_041'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'40'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_042'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_043'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'25'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_044'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'46'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_045'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'40'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_046'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'48'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_047'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'44'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_048'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'37'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_049'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'47'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_09_050'
      ,'SSSRVY_20260327_1_S226_1_09'
      ,'60'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_001'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'49'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_002'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'19'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_003'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_004'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'36'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_005'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'35'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_006'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'22'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_007'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'25'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_008'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'21'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_009'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'24'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_010'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'18'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_011'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'22'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_012'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'29'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_013'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'15'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_014'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'15'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_015'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'26'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_016'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'17'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_017'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'5'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_018'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_019'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_020'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'12'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_021'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_022'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'50'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_023'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_024'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'24'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_025'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'22'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_026'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'7'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_027'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_028'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'15'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_029'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'19'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_030'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'16'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_031'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'23'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_032'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'15'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_033'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'24'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_034'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_035'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'25'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_036'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_037'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'15'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_038'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'35'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_039'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'41'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_040'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'15'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_041'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_042'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'43'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_043'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'18'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_044'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'33'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_045'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'49'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_046'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'10'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_047'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'34'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_048'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'35'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_049'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'31'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_10_050'
      ,'SSSRVY_20260327_1_S226_1_10'
      ,'38'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_001'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_002'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'25'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_003'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'40'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_004'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'45'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_005'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'41'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_006'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'36'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_007'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'32'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_008'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'27'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_009'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_010'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'15'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_011'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'31'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_012'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'33'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_013'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'35'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_014'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'45'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_015'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'13'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_016'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'51'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_017'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_018'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'21'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_019'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_020'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'37'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_021'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'31'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_022'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'57'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_023'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'51'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_024'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_025'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'10'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_026'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'26'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_027'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'18'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_028'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'43'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_029'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_030'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'23'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_031'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'44'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_032'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'23'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_033'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'27'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_034'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'34'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_035'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_036'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'35'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_037'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_038'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'26'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_039'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'31'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_040'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'60'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_041'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'40'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_042'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'51'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_043'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'34'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_044'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'32'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_045'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'22'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_046'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'28'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_047'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'25'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_048'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'36'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_049'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_11_050'
      ,'SSSRVY_20260327_1_S226_1_11'
      ,'21'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_001'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'44'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_002'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'36'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_003'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'31'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_004'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'40'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_005'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'22'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_006'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'27'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_007'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'40'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_008'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'46'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_009'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'21'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_010'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'41'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_011'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'22'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_012'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'19'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_013'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_014'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'41'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_015'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_016'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'15'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_017'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'13'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_018'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_019'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'26'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_020'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'24'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_021'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'41'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_022'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'39'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_023'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_024'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_025'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'35'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_026'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_027'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'36'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_028'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'10'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_029'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'35'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_030'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'36'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_031'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'5'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_032'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_033'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'22'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_034'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'22'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_035'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_036'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'15'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_037'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'27'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_038'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'22'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_039'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_040'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'31'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_041'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_042'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'28'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_043'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'38'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_044'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_045'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_046'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'28'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_047'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_048'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_049'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'22'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_12_050'
      ,'SSSRVY_20260327_1_S226_1_12'
      ,'14'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_13_001'
      ,'SSSRVY_20260327_1_S226_1_13'
      ,'45'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_13_002'
      ,'SSSRVY_20260327_1_S226_1_13'
      ,'19'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_13_003'
      ,'SSSRVY_20260327_1_S226_1_13'
      ,'38'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_13_004'
      ,'SSSRVY_20260327_1_S226_1_13'
      ,'22'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_13_005'
      ,'SSSRVY_20260327_1_S226_1_13'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_13_006'
      ,'SSSRVY_20260327_1_S226_1_13'
      ,'56'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_13_007'
      ,'SSSRVY_20260327_1_S226_1_13'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_13_008'
      ,'SSSRVY_20260327_1_S226_1_13'
      ,'28'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_13_009'
      ,'SSSRVY_20260327_1_S226_1_13'
      ,'31'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_13_010'
      ,'SSSRVY_20260327_1_S226_1_13'
      ,'22'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_13_011'
      ,'SSSRVY_20260327_1_S226_1_13'
      ,'33'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_13_012'
      ,'SSSRVY_20260327_1_S226_1_13'
      ,'32'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_13_013'
      ,'SSSRVY_20260327_1_S226_1_13'
      ,'35'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_13_014'
      ,'SSSRVY_20260327_1_S226_1_13'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_13_015'
      ,'SSSRVY_20260327_1_S226_1_13'
      ,'18'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_13_016'
      ,'SSSRVY_20260327_1_S226_1_13'
      ,'19'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_13_017'
      ,'SSSRVY_20260327_1_S226_1_13'
      ,'11'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_13_018'
      ,'SSSRVY_20260327_1_S226_1_13'
      ,'15'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_13_019'
      ,'SSSRVY_20260327_1_S226_1_13'
      ,'33'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_13_020'
      ,'SSSRVY_20260327_1_S226_1_13'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_13_021'
      ,'SSSRVY_20260327_1_S226_1_13'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_13_022'
      ,'SSSRVY_20260327_1_S226_1_13'
      ,'39'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_13_023'
      ,'SSSRVY_20260327_1_S226_1_13'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_001'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'62'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_002'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'26'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_003'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'19'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_004'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'43'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_005'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'31'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_006'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'56'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_007'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'33'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_008'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'60'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_009'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'24'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_010'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'25'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_011'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'43'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_012'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'46'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_013'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'33'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_014'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'61'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_015'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'47'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_016'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'26'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_017'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'32'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_018'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'46'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_019'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'28'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_020'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_021'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_022'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'27'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_023'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_024'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'36'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_025'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'22'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_026'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'59'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_027'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'29'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_028'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'40'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_029'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'40'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_030'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'40'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_031'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'48'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_032'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'31'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_033'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'21'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_034'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_035'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'36'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_036'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'22'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_037'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'16'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_038'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'10'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_039'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'25'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_040'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'25'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_041'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'21'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_042'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'15'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_043'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'32'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_044'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_045'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'25'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_046'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'56'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_047'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_048'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_049'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'63'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_14_050'
      ,'SSSRVY_20260327_1_S226_1_14'
      ,'14'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_001'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'36'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_002'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'41'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_003'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'27'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_004'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'36'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_005'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'40'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_006'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'45'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_007'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'35'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_008'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'21'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_009'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_010'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'45'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_011'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'13'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_012'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_013'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'19'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_014'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_015'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'34'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_016'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'47'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_017'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'37'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_018'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'35'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_019'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'38'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_020'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'41'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_021'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_022'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'29'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_023'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'25'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_024'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_025'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'40'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_026'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'35'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_027'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_028'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'26'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_029'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'38'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_030'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'23'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_031'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'18'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_032'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'38'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_033'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'31'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_034'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'25'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_035'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_036'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'40'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_037'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_038'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_039'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'51'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_040'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'55'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_041'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'25'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_042'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_043'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'34'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_044'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'36'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_045'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'35'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_046'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'33'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_047'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'42'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_048'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'20'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_049'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'30'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO

INSERT INTO [dbo].[SurveySH]
           ([ShellHeightID]
           ,[QuadratID]
           ,[ShellHeight]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments])
     VALUES
      ('SSSRVY_20260327_1_S226_1_15_050'
      ,'SSSRVY_20260327_1_S226_1_15'
      ,'33'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,NULL)
 GO
