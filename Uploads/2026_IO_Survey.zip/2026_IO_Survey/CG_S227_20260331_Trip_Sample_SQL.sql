
INSERT INTO [dbo].[FixedLocations]
           ([FixedLocationID]
           ,[Estuary]
           ,[SectionName]
           ,[StationName]
           ,[StationNumber]
           ,[LatitudeDec]
           ,[LongitudeDec]
           ,[Recruitment]
           ,[Survey]
           ,[Sediment]
           ,[Collections]
           ,[ShellBudget]
           ,[Dataloggers]
           ,[Cage]
           ,[Wave]
           ,[StartDate]
           ,[EndDate]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments]
           ,[AdminNotes]
           ,[StationNameNumber]
           ,[EstuaryLongName])
VALUES
      ('S227'
      ,'SS'
      ,'S'
      ,'S277'
      ,'277'
      ,'29.15964'
      ,'-82.99936'
      ,'N'
      ,'Y'
      ,'N'
      ,'N'
      ,'N'
      ,'N'
      ,'N'
      ,'N'
      ,'2026-03-31'
      ,'2026-03-31'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'CGO'
      ,'datalogger upload FixedLocationID'
      ,'S277-77'
      ,'Suwannee Sound')
 GO


INSERT INTO [dbo].[TripInfo]
           ([TripID]
           ,[TripType]
           ,[TripDate]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy])
     VALUES
      ('SSSRVY_20260331_1'
      ,'Survey'
      ,'2026-03-31'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze')
 GO


INSERT INTO [dbo].[SampleEvent]
           ([SampleEventID]
           ,[TripID]
           ,[FixedLocationID]
           ,[LatitudeDec]
           ,[LongitudeDec]
           ,[HarvestStatus]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy])
     VALUES
      ('SSSRVY_20260331_1_S227_1'
      ,'SSSRVY_20260331_1'
      ,'S227'
      ,'29.15964'
      ,'-82.99936'
      ,'Conditionally Approved'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze')
 GO


INSERT INTO [dbo].[SampleEventWQ]
           ([SampleEventWQID]
           ,[SampleEventID]
           ,[Temperature]
           ,[Salinity]
           ,[DissolvedOxygen]
           ,[pH]
           ,[Depth]
           ,[TurbidityYSI]
           ,[DataStatus]
           ,[DateEntered]
           ,[EnteredBy]
           ,[DateProofed]
           ,[ProofedBy]
           ,[Comments]
           ,[CollectionTime])
     VALUES
      ('SSSRVY_20260331_1_S227_1_01'
      ,'SSSRVY_20260331_1_S227_1'
      ,'21.5'
      ,'31.1'
      ,'6.42'
      ,'7.65'
      ,'0.5'
      ,'36.97'
      ,'Proofed'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'2026-05-10 00:00:00.000'
      ,'Tomena Scholze'
      ,'Notes = CGO DPTH_STRTA = I BOTTOM_TYP = OY'
      ,'1004')
 GO
